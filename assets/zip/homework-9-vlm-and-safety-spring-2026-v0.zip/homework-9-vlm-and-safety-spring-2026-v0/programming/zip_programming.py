import os
import zipfile
import glob

zip_name = "programming.zip"
programming_dir = os.path.dirname(os.path.abspath(__file__))

include_patterns = ["*.py"]

with zipfile.ZipFile(os.path.join(programming_dir, zip_name), "w", zipfile.ZIP_DEFLATED) as z:
    for pattern in include_patterns:
        for file_path in glob.glob(os.path.join(programming_dir, pattern)):
            arcname = os.path.basename(file_path)
            z.write(file_path, arcname)

print(f"Created {zip_name}")
