import unittest

import numpy as np
import torch

from gradescope_utils.autograder_utils.decorators import weight, number

try:
    from programming.vit import (
        get_patches,
        linear_projection,
        positional_encoding,
        embed_image,
        embed_text,
    )
except ImportError:
    from vit import (
        get_patches,
        linear_projection,
        positional_encoding,
        embed_image,
        embed_text,
    )

# Shared test fixtures
PATCH_SIZE = 16
IMG_SIZE = 64
EMBED_DIM = 128
NUM_PATCHES = (IMG_SIZE // PATCH_SIZE) ** 2  # 16
PATCH_FLAT_GRAY = PATCH_SIZE * PATCH_SIZE       # 256
PATCH_FLAT_RGB  = PATCH_SIZE * PATCH_SIZE * 3   # 768


class TestViT(unittest.TestCase):

    def setUp(self):
        # Deterministic grayscale image: pixel values 0..4095
        self.gray_image = np.arange(
            IMG_SIZE * IMG_SIZE, dtype=np.float32
        ).reshape(IMG_SIZE, IMG_SIZE)

        # Deterministic RGB image
        rng = np.random.default_rng(42)
        self.rgb_image = rng.random((IMG_SIZE, IMG_SIZE, 3)).astype(np.float32)

        self.text = "vision transformer"

    # ------------------------------------------------------------------
    # get_patches tests
    # ------------------------------------------------------------------

    @weight(2)
    @number("4.1")
    def test_get_patches_count(self):
        """get_patches returns the correct number of patches for a 64x64 image."""
        patches = get_patches(self.gray_image, PATCH_SIZE)
        self.assertEqual(
            len(patches),
            NUM_PATCHES,
            f"Expected {NUM_PATCHES} patches, got {len(patches)}",
        )

    @weight(2)
    @number("4.2")
    def test_get_patches_grayscale_shape(self):
        """get_patches output has shape (num_patches, patch_size^2) for grayscale."""
        patches = get_patches(self.gray_image, PATCH_SIZE)
        self.assertEqual(
            patches.shape,
            (NUM_PATCHES, PATCH_FLAT_GRAY),
            f"Expected shape {(NUM_PATCHES, PATCH_FLAT_GRAY)}, got {patches.shape}",
        )

    @weight(2)
    @number("4.3")
    def test_get_patches_rgb_shape(self):
        """get_patches output has shape (num_patches, patch_size^2 * 3) for RGB."""
        patches = get_patches(self.rgb_image, PATCH_SIZE)
        self.assertEqual(
            patches.shape,
            (NUM_PATCHES, PATCH_FLAT_RGB),
            f"Expected shape {(NUM_PATCHES, PATCH_FLAT_RGB)}, got {patches.shape}",
        )

    @weight(2)
    @number("4.4")
    def test_get_patches_values(self):
        """First patch pixel values match the top-left region of the original image."""
        patches = get_patches(self.gray_image, PATCH_SIZE)
        expected_first_patch = self.gray_image[0:PATCH_SIZE, 0:PATCH_SIZE].flatten()
        np.testing.assert_array_equal(
            patches[0],
            expected_first_patch,
            err_msg="First patch values do not match image[0:16, 0:16].flatten()",
        )

    # ------------------------------------------------------------------
    # linear_projection tests
    # ------------------------------------------------------------------

    @weight(2)
    @number("4.5")
    def test_linear_projection_shape(self):
        """linear_projection maps (num_patches, patch_flat) → (num_patches, embedding_dim)."""
        patches = get_patches(self.gray_image, PATCH_SIZE)
        result = linear_projection(patches, EMBED_DIM)
        self.assertEqual(
            tuple(result.shape),
            (NUM_PATCHES, EMBED_DIM),
            f"Expected shape {(NUM_PATCHES, EMBED_DIM)}, got {tuple(result.shape)}",
        )

    @weight(2)
    @number("4.6")
    def test_linear_projection_returns_tensor(self):
        """linear_projection returns a torch.Tensor."""
        patches = get_patches(self.gray_image, PATCH_SIZE)
        result = linear_projection(patches, EMBED_DIM)
        self.assertIsInstance(
            result,
            torch.Tensor,
            f"Expected torch.Tensor, got {type(result)}",
        )

    # ------------------------------------------------------------------
    # positional_encoding tests
    # ------------------------------------------------------------------

    @weight(2)
    @number("4.7")
    def test_positional_encoding_shape(self):
        """positional_encoding returns a tensor of shape (num_patches, embedding_dim)."""
        pe = positional_encoding(NUM_PATCHES, EMBED_DIM)
        self.assertEqual(
            tuple(pe.shape),
            (NUM_PATCHES, EMBED_DIM),
            f"Expected shape {(NUM_PATCHES, EMBED_DIM)}, got {tuple(pe.shape)}",
        )

    @weight(2)
    @number("4.8")
    def test_positional_encoding_rows_unique(self):
        """Each position receives a distinct positional encoding vector."""
        pe = positional_encoding(NUM_PATCHES, EMBED_DIM)
        for i in range(NUM_PATCHES):
            for j in range(i + 1, NUM_PATCHES):
                self.assertFalse(
                    torch.allclose(pe[i], pe[j]),
                    f"Positional encoding rows {i} and {j} are identical",
                )

    # ------------------------------------------------------------------
    # embed_image test
    # ------------------------------------------------------------------

    @weight(2)
    @number("4.9")
    def test_embed_image_shape(self):
        """embed_image returns a tensor of shape (num_patches, embedding_dim)."""
        result = embed_image(self.gray_image, PATCH_SIZE, EMBED_DIM)
        self.assertEqual(
            tuple(result.shape),
            (NUM_PATCHES, EMBED_DIM),
            f"Expected shape {(NUM_PATCHES, EMBED_DIM)}, got {tuple(result.shape)}",
        )

    # ------------------------------------------------------------------
    # embed_text + comparison test
    # ------------------------------------------------------------------

    @weight(2)
    @number("4.10")
    def test_embed_text_dim_matches_image(self):
        """embed_text and embed_image share the same feature dimension."""
        text_emb = embed_text(self.text, EMBED_DIM)
        image_emb = embed_image(self.gray_image, PATCH_SIZE, EMBED_DIM)

        self.assertEqual(
            text_emb.shape[-1],
            EMBED_DIM,
            f"embed_text last dim expected {EMBED_DIM}, got {text_emb.shape[-1]}",
        )
        self.assertEqual(
            text_emb.shape[-1],
            image_emb.shape[-1],
            "embed_text and embed_image do not share the same feature dimension",
        )


if __name__ == "__main__":
    unittest.main()
