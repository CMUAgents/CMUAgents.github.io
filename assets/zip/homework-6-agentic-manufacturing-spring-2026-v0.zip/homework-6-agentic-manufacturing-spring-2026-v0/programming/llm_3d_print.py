"""
LLM-3D Print: Multi-Agent System for Autonomous 3D Printer Control

Defaults to running locally with Qwen/Qwen2-VL-2B-Instruct (no API key needed).
Optionally set OPENAI_API_KEY or ANTHROPIC_API_KEY in the environment to use
GPT-4o or Claude instead.

Reference:
    Jadhav et al. (2025). LLM-3D print: Large language models to monitor
    and control 3D printing. Additive Manufacturing.

Setup:
    1. uv sync
    2. Optionally place print-layer images in DATA_FOLDER/layer_images/
       (the runner falls back to a simulated failure report if no images are found).
    3. uv run python programming/llm_3d_print.py
       # or with an API key:
       OPENAI_API_KEY=sk-... uv run python programming/llm_3d_print.py
       ANTHROPIC_API_KEY=sk-ant-... uv run python programming/llm_3d_print.py
"""

######################
# Configuration      #
######################

DATA_FOLDER = "./data"
MODEL_NAME  = "Qwen/Qwen2-VL-2B-Instruct"   # handles both vision and text

######################
# Imports            #
######################

import base64
import json
import operator
import os
import re
from typing import Annotated, List, Optional, TypedDict

from loguru import logger

from langchain_core.messages import HumanMessage
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages

######################
# Backend Selection  #
######################
# Set OPENAI_API_KEY or ANTHROPIC_API_KEY in the environment to use an API
# backend instead of the local Qwen model.

OPENAI_API_KEY    = os.environ.get("OPENAI_API_KEY")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")

if OPENAI_API_KEY:
    BACKEND = "openai"
elif ANTHROPIC_API_KEY:
    BACKEND = "anthropic"
else:
    BACKEND = "local"

print(f"Backend: {BACKEND}")

######################
# Model Loading      #
######################

if BACKEND == "local":
    import torch
    import transformers
    from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

    try:
        from qwen_vl_utils import process_vision_info
        _HAS_VL_UTILS = True
    except ImportError:
        _HAS_VL_UTILS = False
        print("qwen-vl-utils not found — image inputs will be skipped.")

    transformers.logging.set_verbosity_error()
    print(f"Loading {MODEL_NAME} …")
    processor = AutoProcessor.from_pretrained(MODEL_NAME)
    model = Qwen2VLForConditionalGeneration.from_pretrained(
        MODEL_NAME,
        torch_dtype="auto",
        device_map="auto",
    )
    print("Model ready.\n")
elif BACKEND == "openai":
    import openai as _openai
    _openai_client = _openai.OpenAI(api_key=OPENAI_API_KEY)
    print("Using OpenAI GPT-4o.\n")
elif BACKEND == "anthropic":
    import anthropic as _anthropic
    _anthropic_client = _anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    print("Using Anthropic Claude.\n")

######################
# Inference Utils    #
######################

def _encode_image(image_path: str) -> str:
    """Base64-encode an image file for API backends."""
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def generate_text(prompt: str, max_new_tokens: int = 512) -> str:
    """Generate a text response using the configured backend."""
    if BACKEND == "openai":
        resp = _openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_new_tokens,
        )
        return resp.choices[0].message.content
    elif BACKEND == "anthropic":
        resp = _anthropic_client.messages.create(
            model="claude-opus-4-6",
            max_tokens=max_new_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.content[0].text
    else:
        messages = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
        text = processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        inputs = processor(text=[text], return_tensors="pt").to(model.device)
        with torch.no_grad():
            out = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
        return processor.decode(
            out[0][inputs.input_ids.shape[1]:], skip_special_tokens=True
        )


def parse_json_output(text: str) -> dict:
    """Extract a JSON object from model output; return {} on failure."""
    text = re.sub(r"```(?:json)?\s*|\s*```", "", text).strip()
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    return {}


######################
# Vision Analysis    #
######################

image_system_prompt = (
    "You are an expert in observing and identifying issues in a 3D print. "
    "This image shows an ongoing 3D print from the front camera."
    "Analyze it thoroughly and identify potential issues. "
    "The printer bed is perfectly leveled. Only consider the current layer.\n\n"
    "Respond in this exact format:\n"
    '"Problems": "Problems found / No problems found"\n'
    '"Observations": "[list of detailed observations]"\n'
    '"Failure": [list of failure modes]\n'
    '"Previous solution status": ignore if first layer, else brief result summary\n'
    '"Print_Rating": [number out of 10]'
)

image_user_prompt = (
    "Analyze the current print layer for defects such as stringing, under-extrusion, "
    "layer adhesion issues, or warping. Focus only on the current layer. "
    "Respond in this exact format:\n"
    '"Problems": "Problems found / No problems found"\n'
    '"Observations": "[list of detailed observations]"\n'
    '"Failure": [list of failure modes]\n'
    '"Previous solution status": ignore if no previous layer\n'
    '"Print_Rating": [number out of 10]'
)


def analyze_image(image_path: str, previous_image_path: Optional[str] = None) -> str:
    """Analyze a print-layer image using the configured backend."""
    combined_prompt = f"{image_system_prompt}\n\n{image_user_prompt}"

    if BACKEND == "openai":
        content = []
        if previous_image_path and os.path.exists(previous_image_path):
            content.append({"type": "text",
                            "text": "Previous layer (reference only):"})
            content.append({"type": "image_url", "image_url": {
                "url": f"data:image/jpeg;base64,{_encode_image(previous_image_path)}"}})
        if os.path.exists(image_path):
            content.append({"type": "image_url", "image_url": {
                "url": f"data:image/jpeg;base64,{_encode_image(image_path)}"}})
        content.append({"type": "text", "text": combined_prompt})
        resp = _openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": content}],
            max_tokens=512,
        )
        return resp.choices[0].message.content

    elif BACKEND == "anthropic":
        content = []
        if previous_image_path and os.path.exists(previous_image_path):
            content.append({"type": "text",
                            "text": "Previous layer (reference only):"})
            content.append({"type": "image", "source": {
                "type": "base64", "media_type": "image/jpeg",
                "data": _encode_image(previous_image_path)}})
        if os.path.exists(image_path):
            content.append({"type": "image", "source": {
                "type": "base64", "media_type": "image/jpeg",
                "data": _encode_image(image_path)}})
        content.append({"type": "text", "text": combined_prompt})
        resp = _anthropic_client.messages.create(
            model="claude-opus-4-6",
            max_tokens=512,
            messages=[{"role": "user", "content": content}],
        )
        return resp.content[0].text

    else:
        # Local Qwen2-VL
        content = []
        if previous_image_path and os.path.exists(previous_image_path) and _HAS_VL_UTILS:
            content.append({"type": "image", "image": previous_image_path})
            content.append({"type": "text",
                            "text": "Previous layer (reference only):"})
        if os.path.exists(image_path) and _HAS_VL_UTILS:
            content.append({"type": "image", "image": image_path})
        content.append({"type": "text", "text": combined_prompt})

        messages = [{"role": "user", "content": content}]
        text = processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        has_images = any(c["type"] == "image" for c in content)
        if has_images and _HAS_VL_UTILS:
            image_inputs, _ = process_vision_info(messages)
            inputs = processor(text=[text], images=image_inputs,
                               return_tensors="pt").to(model.device)
        else:
            inputs = processor(text=[text], return_tensors="pt").to(model.device)
        with torch.no_grad():
            out = model.generate(**inputs, max_new_tokens=512, do_sample=False)
        return processor.decode(
            out[0][inputs.input_ids.shape[1]:], skip_special_tokens=True
        )


######################
# Printer Tools      #
######################

def change_parameters(gcode_command: str) -> dict:
    """Execute a G-code command on the printer (simulated)."""
    # Real deployment: POST to Moonraker API
    # requests.post("http://{printer_url}/printer/gcode/script",
    #               json={"script": gcode_command})
    return {"message": f"G-code '{gcode_command}' executed successfully."}


def resume_print() -> str:
    """Resume the print job (simulated)."""
    # Real deployment: requests.post(f"{printer_url}/printer/print/resume")
    return "Print job resumed."


######################
# Image Processing   #
######################

os.environ["QT_QPA_PLATFORM"] = "offscreen"


def load_text_file(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return ""

######################
# Graph State        #
######################

class GraphState(TypedDict):
    printer_url:                str
    information_required:       Annotated[list, operator.add]
    information_known:          Annotated[list, operator.add]
    reasoning:                  List[str]
    adapted_recon_reasoning:    List[str]
    solution_reasoning:         List[str]
    adapter_solution_reasoning: List[str]
    solution_steps:             Annotated[list, add_messages]
    observations:               str
    printer_obj:                str
    gcode_commands:             str
    internal_messages:          Annotated[list, operator.add]
    next:                       str
    previous_solution:          List[str]


######################
# Reasoning Modules  #
######################

reasoning_planner = [
    "What are the possible reasons for the failure?",
    "How to solve the problem in the next layer without human intervention?",
    "What information do you already know?",
    "What additional information do you need to solve the task?",
    "What information can be acquired from the printer without human intervention?",
    "What are the controllable parameters that can be changed to solve the failure?",
    "Based on the observations, what failure modes can you identify?",
    "Which issues are most likely to cause significant problems to print quality?",
    "What printer parameter is most responsible for these observations?",
]

solution_reasoning = [
    "What are the possible reasons for the observed failure?",
    "Given current print parameters, what are the best parameters to adjust?",
    "What controllable parameters can be changed to solve the failure?",
    "What step-by-step instructions would solve the problem without human intervention?",
    "What G-code commands should be used to fix the issue?",
    "What should be the correct values for the parameter changes?",
    "Are bed temperature, extruder temperature, speed, and extrusion factor correct for PLA?",
    "How can cooling or retraction settings be optimized?",
]


######################
# Agent Nodes        #
######################

def info_planner_node(state: GraphState) -> dict:
    """
    Information Planning Agent.
    Adapts generic reasoning to the specific failure, then plans what
    printer data to gather to diagnose the root cause.
    """
    # Step 1: Adapt reasoning to the specific failure
    adapt_prompt = (
        "You are a 3D printing expert. A print failure has been detected.\n\n"
        f"Observations:\n{state['observations']}\n\n"
        f"Generic reasoning modules:\n{json.dumps(state['reasoning'], indent=2)}\n\n"
        f"Known information:\n{json.dumps(list(state['information_known'])[-3:], indent=2)}\n\n"
        "Select the most relevant reasoning steps, reorder them by importance for this "
        "specific failure, and rephrase them to be more targeted.\n\n"
        "Respond with valid JSON only:\n"
        '{"adapted_prompts": ["step 1", "step 2", ...], "preamble": "brief overview"}'
    )
    adapt_out = parse_json_output(generate_text(adapt_prompt, max_new_tokens=400))
    adapted   = adapt_out.get("adapted_prompts", state["reasoning"])

    # Step 2: Plan what information to gather
    plan_prompt = (
        "You are a 3D printing expert. Based on the failure and reasoning, "
        "list the specific printer parameters to query.\n\n"
        f"Observations:\n{state['observations']}\n\n"
        f"Adapted reasoning:\n{json.dumps(adapted, indent=2)}\n\n"
        f"Known information:\n{json.dumps(list(state['information_known'])[-3:], indent=2)}\n\n"
        "Respond with valid JSON only:\n"
        '{"information_required": ["param 1", "param 2", ...], '
        '"potential_causes": ["cause 1", "cause 2", ...]}'
    )
    plan_out = parse_json_output(generate_text(plan_prompt, max_new_tokens=400))
    required = plan_out.get("information_required",
                             ["Current extruder temperature", "Current print speed"])

    return {
        "adapted_recon_reasoning": adapted,
        "information_required":    required if isinstance(required, list) else [required],
        "internal_messages":       [HumanMessage(
            "Plan generated for information gathering, go to next step"
        )],
    }


def recon_executor_node(state: GraphState) -> dict:
    """
    Reconnaissance Executor.
    In a real deployment this queries the live Moonraker printer API.
    Here we load pre-recorded data from a JSON file.
    """
    info_path = os.path.join(DATA_FOLDER, "information_known.json")
    if os.path.exists(info_path):
        with open(info_path, "r") as f:
            data = json.load(f)
        layer      = os.getenv("LAYER_NUM", "0")
        extracted  = data.get(str(layer), "No data for this layer").split("\n")
    else:
        extracted = ["No pre-recorded data found — using initial printer state only."]

    return {
        "information_known":  extracted,
        "internal_messages":  [HumanMessage("Information gathered from the printer")],
    }


def sol_planner_node(state: GraphState) -> dict:
    """
    Solution Planning Agent.
    Adapts solution reasoning to the failure, then generates specific
    G-code commands or parameter changes to fix the issue.
    """
    # Step 1: Adapt solution reasoning
    adapt_prompt = (
        "You are a 3D printing expert. Adapt the solution reasoning to this failure.\n\n"
        f"Observations:\n{state['observations']}\n\n"
        f"Gathered information:\n{json.dumps(list(state['information_known'])[-5:], indent=2)}\n\n"
        f"Solution reasoning modules:\n{json.dumps(state['solution_reasoning'], indent=2)}\n\n"
        "Select, reorder, and rephrase the reasoning steps for this specific failure.\n\n"
        "Respond with valid JSON only:\n"
        '{"adapted_prompts": ["step 1", "step 2", ...], "preamble": "brief overview"}'
    )
    adapt_out = parse_json_output(generate_text(adapt_prompt, max_new_tokens=400))
    adapted   = adapt_out.get("adapted_prompts", state["solution_reasoning"])

    # Step 2: Generate solution plan
    plan_prompt = (
        "You are a 3D printing expert. Create a solution plan to fix the print failure.\n\n"
        f"Observations:\n{state['observations']}\n\n"
        f"Gathered information:\n{json.dumps(list(state['information_known'])[-5:], indent=2)}\n\n"
        f"Solution reasoning:\n{json.dumps(adapted, indent=2)}\n\n"
        f"Previous solutions:\n{json.dumps(state['previous_solution'], indent=2)}\n\n"
        "Generate specific G-code commands or parameter changes. "
        "Be precise with numerical values. No human intervention required.\n\n"
        "Respond with valid JSON only:\n"
        '{"step_commands_to_run": ["M104 S210", "M106 S128", ...], '
        '"potential_causes": ["cause 1", "cause 2"]}'
    )
    plan_out = parse_json_output(generate_text(plan_prompt, max_new_tokens=500))
    steps    = plan_out.get("step_commands_to_run",
                             ["M104 S210  ; adjust nozzle temperature"])

    return {
        "adapter_solution_reasoning": adapted,
        "solution_steps":             [HumanMessage(steps)],
        "internal_messages":          [HumanMessage(
            "Solution plan generated, go to next step"
        )],
    }


def sol_executor_node(state: GraphState) -> dict:
    """
    Solution Executor.
    Applies each planned parameter change on the printer.
    Implements a lightweight ReAct-style loop: for each step, ask the
    model to produce the G-code command, then call change_parameters().
    """
    if state["solution_steps"]:
        steps = state["solution_steps"][0].content
        for step in (steps if isinstance(steps, list) else [steps]):
            # Use the model to translate the step into a concrete G-code command
            cmd_prompt = (
                f"Translate this 3D printing fix into a single G-code command:\n{step}\n\n"
                "Respond with only the G-code command string, nothing else.\n"
                "Example: M104 S215"
            )
            gcode  = generate_text(cmd_prompt, max_new_tokens=60).strip().split("\n")[0]
            result = change_parameters(gcode)
            print(f"  Executed: {gcode}  →  {result['message']}")

    return {
        "internal_messages": [HumanMessage(
            "Parameters changed on the printer, go to resume print"
        )],
    }


def resume_print_node(state: GraphState) -> dict:
    """Resumes the printer after all corrections have been applied."""
    msg = resume_print()
    print(f"  {msg}")
    return {
        "internal_messages": [HumanMessage("Print resumed. FINISH.")],
    }


def supervisor_node(state: GraphState) -> dict:
    """
    Supervisor Agent.
    Routes to the next appropriate worker based on which pipeline stages
    have already completed (tracked via internal_messages).
    """
    def msgs_contain(text: str) -> bool:
        for m in state.get("internal_messages", []):
            content = m.content if isinstance(m.content, str) else str(m.content)
            if text in content:
                return True
        return False

    if msgs_contain("Print resumed"):
        return {"next": "FINISH"}
    elif msgs_contain("Parameters changed on the printer"):
        return {"next": "resume_print"}
    elif msgs_contain("Solution plan generated"):
        return {"next": "sol_executor"}
    elif msgs_contain("Information gathered"):
        return {"next": "sol_planner"}
    elif msgs_contain("Plan generated for information gathering"):
        return {"next": "recon_executor"}
    else:
        return {"next": "info_planner"}


######################
# Graph Construction #
######################

def get_graph():
    """Build and compile the multi-agent LangGraph workflow."""
    members = ["info_planner", "recon_executor", "sol_planner",
               "sol_executor", "resume_print"]

    workflow = StateGraph(GraphState)

    # Add all agent nodes
    workflow.add_node("supervisor",    supervisor_node)
    workflow.add_node("info_planner",  info_planner_node)
    workflow.add_node("recon_executor", recon_executor_node)
    workflow.add_node("sol_planner",   sol_planner_node)
    workflow.add_node("sol_executor",  sol_executor_node)
    workflow.add_node("resume_print",  resume_print_node)

    # Each worker reports back to the supervisor when done
    for member in members:
        workflow.add_edge(member, "supervisor")

    # Supervisor routes conditionally to a worker or FINISH
    conditional_map = {k: k for k in members}
    conditional_map["FINISH"] = END
    workflow.add_conditional_edges("supervisor", lambda x: x["next"], conditional_map)

    workflow.set_entry_point("supervisor")
    return workflow.compile()


######################
# Main Runner        #
######################

def runner(
    printer_url:     str = "192.168.0.1",
    image_save_path: str = None,
    save_path:       str = None,
) -> None:
    """
    Process each print layer through the multi-agent system.

    Images are discovered from image_save_path in sorted filename order —
    any naming convention works (e.g. 001.jpg, 002.jpg, layer_3.png, …).
    Each image is treated as one layer; the previous image is passed as
    the reference for comparison.

    Args:
        printer_url:     Printer IP (unused with pre-recorded data).
        image_save_path: Directory containing layer images.
        save_path:       Directory to write result text files.
    """
    if image_save_path is None:
        image_save_path = os.path.join(DATA_FOLDER, "layer_images")
    if save_path is None:
        save_path = DATA_FOLDER
    os.makedirs(save_path, exist_ok=True)

    # Discover images in sorted order — any filename, any common extension
    exts = (".jpg", ".jpeg", ".png", ".bmp", ".tiff")
    image_paths = []
    if os.path.isdir(image_save_path):
        image_paths = sorted([
            os.path.join(image_save_path, f)
            for f in os.listdir(image_save_path)
            if f.lower().endswith(exts)
        ])

    if not image_paths:
        image_paths = [None]   # run once with simulated failure

    for idx, current_img in enumerate(image_paths):
        prev_img   = image_paths[idx - 1] if idx > 0 else None
        layer_label = os.path.basename(current_img) if current_img else "simulated"
        os.environ["LAYER_NUM"] = str(idx)

        print(f"\n{'='*60}\nProcessing {layer_label} ({idx + 1}/{len(image_paths)})\n{'='*60}\n")

        # Vision analysis — falls back to a simulated report if no image exists
        if current_img and os.path.exists(current_img):
            print("Analyzing print layer image …")
            failures = analyze_image(current_img, prev_img)
        else:
            failures = (
                '"Problems": "Problems found"\n'
                '"Observations": ["Under-extrusion visible in current layer"]\n'
                '"Failure": ["Under-extrusion"]\n'
                '"Previous solution status": "N/A"\n'
                '"Print_Rating": 6'
            )
            print("No image found — using simulated failure report.")

        with open(os.path.join(save_path, f"failures_{idx}.txt"), "w") as f:
            f.write(failures)
        print(f"\033[92mDetected:\n{failures}\033[0m\n")

        # Load previous solution (for context)
        prev_sol_path = os.path.join(save_path, f"new_solution_{idx - 1}.txt")
        prev_sol = load_text_file(prev_sol_path).split("\n") if \
                   os.path.exists(prev_sol_path) else []

        # Run the multi-agent graph
        graph   = get_graph()
        logfile = os.path.join(save_path, f"log_{idx}.log")
        logger.add(logfile, colorize=True, enqueue=True)

        out = graph.invoke({
            "printer_url":               printer_url,
            "information_known": [
                "Filament type is PLA",
                "Printer model is Creality Ender 5 Plus",
                "Printer status is paused",
                f"Current image is {layer_label}",
                "Bed is perfectly calibrated",
                "Nozzle diameter is 1 mm",
                "Layer height is 0.3 mm",
                "Infill pattern is aligned rectilinear",
            ],
            "observations":               failures,
            "reasoning":                  reasoning_planner,
            "solution_reasoning":         solution_reasoning,
            "printer_obj":                "",
            "gcode_commands":             "",
            "adapted_recon_reasoning":    [],
            "adapter_solution_reasoning": [],
            "previous_solution":          prev_sol,
            "solution_steps":             [],
            "information_required":       [],
            "internal_messages":          [],
            "next":                       "",
        })

        sol_text = str(out.get("solution_steps", []))
        with open(os.path.join(save_path, f"new_solution_{idx}.txt"), "w") as f:
            f.write(sol_text)
        print(f"\nSolution for {layer_label}:\n{sol_text}\n")

    print("✓ Processing complete!")


if __name__ == "__main__":
    runner()
