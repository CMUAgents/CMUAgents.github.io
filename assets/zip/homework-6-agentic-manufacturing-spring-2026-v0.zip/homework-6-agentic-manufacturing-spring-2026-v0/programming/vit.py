import math

import numpy as np
import torch
import torch.nn as nn


###########
# Patches #
###########

def get_patches(image: np.ndarray, patch_size: int) -> np.ndarray:
    """
    Split an image into non-overlapping square patches.

    Args:
        image: numpy array of shape (H, W) for grayscale or (H, W, C) for RGB.
               H and W must both be divisible by patch_size.
        patch_size: side length (in pixels) of each square patch.

    Returns:
        numpy array of shape (num_patches, patch_size * patch_size * C)
        where num_patches = (H // patch_size) * (W // patch_size)
        and C = 1 for grayscale, 3 for RGB.
        Patches are ordered left-to-right, top-to-bottom.
    """
    # Fill in


######################
# Linear Projection  #
######################

def linear_projection(
    patches: np.ndarray,
    embedding_dim: int,
    seed: int = 42,
) -> torch.Tensor:
    """
    Apply a linear projection to map patch vectors to an embedding space.

    Uses a single torch.nn.Linear layer (no bias) with deterministic weight
    initialization controlled by seed.

    Args:
        patches: numpy array of shape (num_patches, patch_flat_dim).
        embedding_dim: output embedding dimension.
        seed: random seed for reproducible weight initialization.

    Returns:
        torch.Tensor of shape (num_patches, embedding_dim).
    """
    # Fill in


########################
# Positional Encoding  #
########################

def positional_encoding(num_patches: int, embedding_dim: int) -> torch.Tensor:
    """
    Compute sinusoidal positional encodings.

    Uses the formulation from "Attention is All You Need" (Vaswani et al. 2017):
        PE(pos, 2i)   = sin(pos / 10000^(2i / d))
        PE(pos, 2i+1) = cos(pos / 10000^(2i / d))

    Args:
        num_patches: number of positions (one per patch).
        embedding_dim: embedding dimension d.

    Returns:
        torch.Tensor of shape (num_patches, embedding_dim).
    """
    # Fill in


##########################
# Full Image Embedding   #
##########################

def embed_image(
    image: np.ndarray,
    patch_size: int,
    embedding_dim: int,
    seed: int = 42,
) -> torch.Tensor:
    """
    Full ViT image embedding pipeline.

    Steps:
        1. Split the image into patches with get_patches.
        2. Apply linear_projection to map patches to embedding_dim.
        3. Add sinusoidal positional_encoding to retain spatial order.

    Args:
        image: numpy array of shape (H, W) or (H, W, C).
        patch_size: side length of each square patch.
        embedding_dim: dimension of the output embeddings.
        seed: random seed passed to linear_projection.

    Returns:
        torch.Tensor of shape (num_patches, embedding_dim).
    """
    # Fill in


######################
# Text Embedding     #
######################

def embed_text(text: str, embedding_dim: int, seed: int = 42) -> torch.Tensor:
    """
    Embed a text string using character-level embeddings.

    Maps each ASCII character to a learned embedding vector via
    torch.nn.Embedding, then averages over all characters to produce a
    single vector.  This gives an embedding in the same feature space as
    the image patch embeddings produced by embed_image.

    Args:
        text: input string (characters are clamped to ASCII range 0-127).
        embedding_dim: output embedding dimension.
        seed: random seed for reproducible weight initialization.

    Returns:
        torch.Tensor of shape (1, embedding_dim).
    """
    # Fill in


if __name__ == "__main__":
    # Example: 64x64 grayscale image with patch_size=16 → 16 patches
    img = np.random.default_rng(0).random((64, 64)).astype(np.float32)

    image_embeddings = embed_image(img, patch_size=16, embedding_dim=128)
    print(f"Image embeddings shape: {image_embeddings.shape}")  # (16, 128)

    # Embed a text string for comparison
    text = "vision transformer patch embedding"
    text_embedding = embed_text(text, embedding_dim=128)
    print(f"Text embedding shape:   {text_embedding.shape}")   # (1, 128)
    print(f"Shared embedding dim:   {image_embeddings.shape[-1] == text_embedding.shape[-1]}")
