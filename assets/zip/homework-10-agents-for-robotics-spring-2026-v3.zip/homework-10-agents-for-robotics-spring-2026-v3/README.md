# homework-template
General template for homeworks including LaTeX writeups and Python boilerplate via `uv`

## Latex
- Fill in areas such as Homework number, homework topic, outdate, and duedate
- Recommended to create homework in `handout_solution.tex`, copy over file to `handout.tex` and edit to hide answers.

## Release
- **Make sure zip files are created by GitHub Release**
  - Just simply zipping repository will include solutions!

## Autograder
- Remember to update `run_autograder` with appropriate files.
- Run `uv run autograder/zip_autograder.py` and upload those files to gradescope.

