import unittest

from gradescope_utils.autograder_utils.decorators import weight, number

try:
    from programming.saycan import (
        SKILLS,
        affordance_score,
        execute_skill,
        joint_score,
        llm_score,
        saycan,
        select_skill,
    )
except ImportError:
    from saycan import (
        SKILLS,
        affordance_score,
        execute_skill,
        joint_score,
        llm_score,
        saycan,
        select_skill,
    )


# ---------------------------------------------------------------------------
# Shared test states
# ---------------------------------------------------------------------------

APPLE_REACHABLE = {
    "reachable_objects": ["apple", "mug", "plate"],
    "held_object": None,
    "open_containers": [],
}

APPLE_NOT_REACHABLE = {
    "reachable_objects": ["mug", "plate"],
    "held_object": None,
    "open_containers": [],
}

HOLDING_APPLE_FRIDGE_CLOSED = {
    "reachable_objects": [],
    "held_object": "apple",
    "open_containers": [],
}

HOLDING_APPLE_FRIDGE_OPEN = {
    "reachable_objects": [],
    "held_object": "apple",
    "open_containers": ["fridge"],
}

# State where only pick_up_apple has high affordance among "pick up" skills:
# fridge and cabinet are already open so open_fridge/open_cabinet score 0.05,
# mug and plate are not reachable so pick_up_mug/pick_up_plate score 0.05.
# Remaining 0.9 skills: pick_up_apple, close_fridge, close_cabinet.
# For the instruction "Pick up the apple." the LLM should clearly prefer
# pick_up_apple over the two close actions even with a 0.5B model.
APPLE_ONLY_PICKUP_FEASIBLE = {
    "reachable_objects": ["apple"],
    "held_object": None,
    "open_containers": ["fridge", "cabinet"],
}


class TestLLMScore(unittest.TestCase):

    @weight(5)
    @number("2.1")
    def test_llm_score_returns_float_in_range(self):
        """llm_score returns a float in [0.0, 1.0]."""
        score = llm_score("Pick up the apple.", "pick_up_apple")
        self.assertIsInstance(score, float)
        self.assertGreaterEqual(score, 0.0)
        self.assertLessEqual(score, 1.0)

    @weight(10)
    @number("2.2")
    def test_llm_score_relevant_skill_in_range(self):
        """llm_score returns a float in [0.0, 1.0] for fill_mug_with_water."""
        score = llm_score("Pick up the apple.", "fill_mug_with_water")
        self.assertIsInstance(score, float)
        self.assertGreaterEqual(score, 0.0)
        self.assertLessEqual(score, 1.0)

    @weight(5)
    @number("2.3")
    def test_llm_score_different_skill_in_range(self):
        """llm_score returns a float in [0.0, 1.0] for pick_up_mug."""
        score = llm_score("Pick up the mug.", "pick_up_mug")
        self.assertIsInstance(score, float)
        self.assertGreaterEqual(score, 0.0)
        self.assertLessEqual(score, 1.0)


class TestAffordanceScore(unittest.TestCase):

    @weight(5)
    @number("2.4")
    def test_affordance_feasible_pickup(self):
        """pick_up_apple returns 0.9 when apple is reachable and nothing is held."""
        score = affordance_score("pick_up_apple", APPLE_REACHABLE)
        self.assertAlmostEqual(score, 0.9)

    @weight(5)
    @number("2.5")
    def test_affordance_infeasible_pickup(self):
        """pick_up_apple returns 0.05 when apple is not in reachable_objects."""
        score = affordance_score("pick_up_apple", APPLE_NOT_REACHABLE)
        self.assertAlmostEqual(score, 0.05)

    @weight(5)
    @number("2.6")
    def test_affordance_place_in_fridge_when_closed(self):
        """place_item_in_fridge returns 0.05 when fridge is not open."""
        score = affordance_score("place_item_in_fridge", HOLDING_APPLE_FRIDGE_CLOSED)
        self.assertAlmostEqual(score, 0.05)


class TestJointScore(unittest.TestCase):

    @weight(5)
    @number("2.7")
    def test_joint_score_equals_product(self):
        """joint_score equals llm_score * affordance_score for a feasible action."""
        instruction = "Pick up the apple."
        skill = "pick_up_apple"
        # Greedy decoding is deterministic, so calling llm_score twice gives the same value.
        expected = llm_score(instruction, skill) * affordance_score(skill, APPLE_REACHABLE)
        result = joint_score(instruction, skill, APPLE_REACHABLE)
        self.assertAlmostEqual(result, expected, places=3)

    @weight(5)
    @number("2.8")
    def test_joint_score_infeasible_is_near_zero(self):
        """joint_score is near zero when the action is physically infeasible."""
        score = joint_score("Pick up the apple.", "pick_up_apple", APPLE_NOT_REACHABLE)
        # affordance is 0.05 and llm_score <= 1.0, so joint <= 0.05
        self.assertLess(score, 0.1)


class TestSelectSkill(unittest.TestCase):

    @weight(5)
    @number("2.9")
    def test_select_skill_returns_valid_skill(self):
        """select_skill returns a string that is in SKILLS."""
        skill = select_skill("Pick up the apple.", APPLE_REACHABLE)
        self.assertIsInstance(skill, str)
        self.assertIn(skill, SKILLS)

    @weight(5)
    @number("2.10")
    def test_select_skill_picks_feasible_skill(self):
        """For 'Pick up the apple.' with apple as the only reachable object, a physically feasible skill is selected."""
        # APPLE_ONLY_PICKUP_FEASIBLE: only pick_up_apple, close_fridge, and close_cabinet
        # have affordance 0.9; all other skills score 0.05.
        # Any of these three is acceptable — the joint score must favour a feasible action.
        FEASIBLE = {"pick_up_apple", "close_fridge", "close_cabinet"}
        skill = select_skill("Pick up the apple.", APPLE_ONLY_PICKUP_FEASIBLE)
        self.assertIn(skill, FEASIBLE)


class TestSayCan(unittest.TestCase):

    @weight(5)
    @number("2.11")
    def test_saycan_returns_list(self):
        """saycan returns a list."""
        plan = saycan("Pick up the apple.", APPLE_REACHABLE, max_steps=3)
        self.assertIsInstance(plan, list)

    @weight(5)
    @number("2.12")
    def test_saycan_respects_max_steps(self):
        """saycan never executes more skills than max_steps."""
        max_steps = 3
        plan = saycan("Put the apple in the fridge.", APPLE_REACHABLE, max_steps=max_steps)
        self.assertLessEqual(len(plan), max_steps)

    @weight(5)
    @number("2.13")
    def test_saycan_all_skills_valid(self):
        """Every skill in the returned plan is a member of SKILLS."""
        plan = saycan("Pick up the apple.", APPLE_REACHABLE, max_steps=5)
        for skill in plan:
            self.assertIn(skill, SKILLS)

    @weight(10)
    @number("2.14")
    def test_saycan_pick_up_apple_task(self):
        """'Pick up the apple.' plan includes pick_up_apple somewhere in the plan."""
        # Uses APPLE_ONLY_PICKUP_FEASIBLE so pick_up_apple has high joint score.
        # We check that pick_up_apple appears anywhere in the plan rather than
        # requiring it as the very first step.
        plan = saycan("Pick up the apple.", APPLE_ONLY_PICKUP_FEASIBLE, max_steps=5)
        self.assertTrue(len(plan) > 0)
        self.assertIn("pick_up_apple", plan)


if __name__ == "__main__":
    unittest.main()
