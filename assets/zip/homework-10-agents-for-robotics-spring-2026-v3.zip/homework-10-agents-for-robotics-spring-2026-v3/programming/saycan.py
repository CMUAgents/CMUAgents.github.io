import re
import random
import torch
import transformers

from rich.console import Console
from rich.panel import Panel
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline, GenerationConfig

console = Console()

transformers.logging.set_verbosity_error()

# Set seeds for reproducibility
random.seed(42)
torch.manual_seed(42)
torch.cuda.manual_seed_all(42)

#########
# Model #
#########

model_name = "Qwen/Qwen2-1.5B-Instruct"

print(f"Loading model {model_name} …")
tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    device_map="cpu",
    torch_dtype="auto"
)

gen = pipeline(
    "text-generation",
    model=model,
    tokenizer=tokenizer,
    device_map="cpu",
    return_full_text=False,
)

generation_config = GenerationConfig(max_new_tokens=16, do_sample=False)

def generate(prompt: str) -> str:
    out = gen(prompt, generation_config=generation_config)
    return out[0]["generated_text"]

################
# Skill Library #
################

SKILLS = [
    "pick_up_apple",
    "pick_up_mug",
    "pick_up_plate",
    "open_fridge",
    "close_fridge",
    "place_item_in_fridge",
    "place_item_on_counter",
    "place_item_on_table",
    "fill_mug_with_water",
    "open_cabinet",
    "close_cabinet",
    "done",
]

SKILL_DESCRIPTIONS = {
    "pick_up_apple":       "Pick up the apple.",
    "pick_up_mug":         "Pick up the mug.",
    "pick_up_plate":       "Pick up the plate.",
    "open_fridge":         "Open the refrigerator door.",
    "close_fridge":        "Close the refrigerator door.",
    "place_item_in_fridge":"Place the held item inside the refrigerator.",
    "place_item_on_counter":"Place the held item on the kitchen counter.",
    "place_item_on_table": "Place the held item on the dining table.",
    "fill_mug_with_water": "Fill the mug with water from the sink.",
    "open_cabinet":        "Open the kitchen cabinet.",
    "close_cabinet":       "Close the kitchen cabinet.",
    "done":                "The task is complete.",
}

###############
# Robot State #
###############

# A robot_state dictionary has the following keys:
#   "reachable_objects" : list[str]  — objects the robot can currently reach
#   "held_object"       : str | None — object currently held by the robot
#   "open_containers"   : list[str]  — containers currently open ("fridge", "cabinet")

def execute_skill(skill: str, robot_state: dict) -> dict:
    """Execute a skill and return the updated robot state. (Provided — do not modify.)"""
    # Deep-copy mutable fields so the original state is not mutated
    state = {
        k: (list(v) if isinstance(v, list) else v)
        for k, v in robot_state.items()
    }

    if skill == "pick_up_apple":
        if "apple" in state["reachable_objects"] and state["held_object"] is None:
            state["reachable_objects"].remove("apple")
            state["held_object"] = "apple"

    elif skill == "pick_up_mug":
        if "mug" in state["reachable_objects"] and state["held_object"] is None:
            state["reachable_objects"].remove("mug")
            state["held_object"] = "mug"

    elif skill == "pick_up_plate":
        if "plate" in state["reachable_objects"] and state["held_object"] is None:
            state["reachable_objects"].remove("plate")
            state["held_object"] = "plate"

    elif skill == "open_fridge":
        if "fridge" not in state["open_containers"]:
            state["open_containers"].append("fridge")

    elif skill == "close_fridge":
        if "fridge" in state["open_containers"]:
            state["open_containers"].remove("fridge")

    elif skill == "place_item_in_fridge":
        if state["held_object"] is not None and "fridge" in state["open_containers"]:
            state["held_object"] = None

    elif skill == "place_item_on_counter":
        if state["held_object"] is not None:
            state["reachable_objects"].append(state["held_object"])
            state["held_object"] = None

    elif skill == "place_item_on_table":
        if state["held_object"] is not None:
            state["held_object"] = None

    elif skill == "fill_mug_with_water":
        pass  # mug is now full; state structure unchanged

    elif skill == "open_cabinet":
        if "cabinet" not in state["open_containers"]:
            state["open_containers"].append("cabinet")

    elif skill == "close_cabinet":
        if "cabinet" in state["open_containers"]:
            state["open_containers"].remove("cabinet")

    return state

#########################
# Functions to Fill In  #
#########################

def llm_score(instruction: str, skill: str) -> float:
    """
    Ask the LLM how appropriate this skill is as the next step for the
    given instruction.

    Steps:
      1. Build a prompt using the instruction and SKILL_DESCRIPTIONS[skill]
         that asks the model to respond with a single float from 0.0 (not
         appropriate) to 1.0 (very appropriate).
      2. Call generate(prompt) and parse the first float found in the
         response using a regex.
      3. Clamp the result to [0.0, 1.0] and return it.
         If no float can be parsed, return 0.0.

    Args:
        instruction: The high-level task instruction (e.g. "pick up the apple").
        skill:       A key from SKILLS (e.g. "pick_up_apple").

    Returns:
        A float in [0.0, 1.0].
    """
    # Fill in


def affordance_score(skill: str, robot_state: dict) -> float:
    """
    Rule-based affordance score: estimated P(success | current state, skill).

    Return 0.9 when the action is physically feasible, 0.05 when it is not.

    Feasibility rules:
      - pick_up_apple   : "apple" in reachable_objects AND held_object is None
      - pick_up_mug     : "mug"   in reachable_objects AND held_object is None
      - pick_up_plate   : "plate" in reachable_objects AND held_object is None
      - open_fridge     : "fridge"  NOT in open_containers
      - close_fridge    : "fridge"  in open_containers
      - place_item_in_fridge  : held_object is not None AND "fridge" in open_containers
      - place_item_on_counter : held_object is not None
      - place_item_on_table   : held_object is not None
      - fill_mug_with_water   : held_object == "mug"
      - open_cabinet    : "cabinet" NOT in open_containers
      - close_cabinet   : "cabinet" in open_containers
      - done            : always returns 0.1 (the LLM decides when the task is truly done)

    Args:
        skill:       A key from SKILLS.
        robot_state: Current robot state dictionary.

    Returns:
        0.9 (feasible), 0.05 (infeasible), or 0.1 (done).
    """
    # Fill in


def joint_score(instruction: str, skill: str, robot_state: dict) -> float:
    """
    Compute the SayCan joint score for a candidate skill.

    The joint score is the product of the LLM semantic score and the
    affordance score:

        joint = llm_score(instruction, skill) * affordance_score(skill, robot_state)

    Args:
        instruction: The high-level task instruction.
        skill:       A key from SKILLS.
        robot_state: Current robot state dictionary.

    Returns:
        A float in [0.0, 1.0].
    """
    # Fill in


def select_skill(instruction: str, robot_state: dict) -> str:
    """
    Select the skill from SKILLS with the highest joint score.

    Args:
        instruction: The high-level task instruction.
        robot_state: Current robot state dictionary.

    Returns:
        The name of the best skill (a key from SKILLS).
    """
    # Fill in


def saycan(instruction: str, robot_state: dict, max_steps: int = 10) -> list:
    """
    Run the SayCan planning loop for a kitchen robot.

    At each step:
      1. Select the best skill with select_skill.
      2. Print the selected skill (for visibility).
      3. Execute it with execute_skill to obtain the next robot state.
      4. Append the skill name to the plan.
      5. If the selected skill is "done", stop the loop.

    Args:
        instruction: The high-level task instruction (e.g. "Put the apple in the fridge.").
        robot_state: Initial robot state dictionary.
        max_steps:   Maximum number of skills to execute.

    Returns:
        A list of skill names in the order they were executed.
    """
    # Fill in


if __name__ == "__main__":
    initial_state = {
        "reachable_objects": ["apple", "mug", "plate"],
        "held_object": None,
        "open_containers": [],
    }

    console.print(Panel("Put the apple in the fridge.", title="Instruction", border_style="blue"))
    plan = saycan("Put the apple in the fridge.", initial_state, max_steps=10)
    console.print(Panel(str(plan), title="Executed Plan", border_style="magenta"))
