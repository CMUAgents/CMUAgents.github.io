import random
import unittest
import numpy as np
import torch

from gradescope_utils.autograder_utils.decorators import weight, number

# Set seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

# Force CPU for consistent results with autograder
torch.set_default_device("cpu")

try:
    from programming.dpr import (
        preprocess_query,
        preprocess_passage,
        chunk_document,
        SimpleDPR,
        SEP_TOKEN,
    )
except ImportError:
    from dpr import (
        preprocess_query,
        preprocess_passage,
        chunk_document,
        SimpleDPR,
        SEP_TOKEN,
    )


class TestDPRPreprocessing(unittest.TestCase):
    """Tests for DPR preprocessing functions."""

    @weight(2)
    @number("2.1")
    def test_preprocess_query(self):
        """Test that preprocess_query correctly appends [SEP] token."""
        query = "What is machine learning?"
        result = preprocess_query(query)
        expected = f"What is machine learning? {SEP_TOKEN}"
        self.assertEqual(result, expected)

    @weight(2)
    @number("2.2")
    def test_preprocess_passage(self):
        """Test that preprocess_passage correctly combines title and text with [SEP]."""
        title = "Machine Learning"
        text = "ML is a field of study in artificial intelligence."
        result = preprocess_passage(title, text)
        expected = f"Machine Learning {SEP_TOKEN} ML is a field of study in artificial intelligence."
        self.assertEqual(result, expected)


class TestDPRChunking(unittest.TestCase):
    """Tests for document chunking function."""

    @weight(2)
    @number("2.3")
    def test_chunk_document_basic(self):
        """Test basic document chunking with exact chunk size."""
        title = "Test Article"
        # Create text with exactly 200 words
        text = " ".join(["word"] * 200)
        chunks = chunk_document(title, text, chunk_size=100)

        self.assertEqual(len(chunks), 2)
        self.assertEqual(chunks[0]["title"], "Test Article")
        self.assertEqual(chunks[1]["title"], "Test Article")
        self.assertEqual(len(chunks[0]["text"].split()), 100)
        self.assertEqual(len(chunks[1]["text"].split()), 100)

    @weight(2)
    @number("2.4")
    def test_chunk_document_remainder(self):
        """Test document chunking with remainder words."""
        title = "AI Overview"
        # Create text with 250 words (should create 3 chunks: 100, 100, 50)
        text = " ".join(["word"] * 250)
        chunks = chunk_document(title, text, chunk_size=100)

        self.assertEqual(len(chunks), 3)
        self.assertEqual(len(chunks[0]["text"].split()), 100)
        self.assertEqual(len(chunks[1]["text"].split()), 100)
        self.assertEqual(len(chunks[2]["text"].split()), 50)


class TestSimpleDPR(unittest.TestCase):
    """Tests for SimpleDPR class."""

    @classmethod
    def setUpClass(cls):
        """Initialize DPR model once for all tests."""
        cls.dpr = SimpleDPR()
        cls.sample_passages = [
            {
                "title": "Machine Learning",
                "text": "Machine learning is a subset of artificial intelligence that enables systems to learn from data."
            },
            {
                "title": "Deep Learning",
                "text": "Deep learning uses neural networks with multiple layers to process complex patterns in data."
            },
            {
                "title": "Natural Language Processing",
                "text": "NLP gives machines the ability to read, understand, and derive meaning from human languages."
            },
            {
                "title": "Computer Vision",
                "text": "Computer vision trains computers to interpret and understand visual information from images."
            },
        ]

    @weight(2)
    @number("2.5")
    def test_encode_returns_numpy_array(self):
        """Test that encode returns a numpy array."""
        texts = ["Hello world", "Test sentence"]
        embeddings = self.dpr.encode(texts)

        self.assertIsInstance(embeddings, np.ndarray)
        self.assertEqual(embeddings.shape[0], 2)

    @weight(2)
    @number("2.6")
    def test_encode_embedding_dimension(self):
        """Test that encode returns correct embedding dimension."""
        texts = ["Single text"]
        embeddings = self.dpr.encode(texts)

        # all-MiniLM-L6-v2 produces 384-dimensional embeddings
        self.assertEqual(embeddings.shape[1], 384)

    @weight(2)
    @number("2.7")
    def test_index_passages_stores_passages(self):
        """Test that index_passages stores passages correctly."""
        dpr = SimpleDPR()
        dpr.index_passages(self.sample_passages)

        self.assertEqual(len(dpr.passages), 4)
        self.assertEqual(dpr.passages[0]["title"], "Machine Learning")

    @weight(2)
    @number("2.8")
    def test_index_passages_creates_embeddings(self):
        """Test that index_passages creates passage embeddings."""
        dpr = SimpleDPR()
        dpr.index_passages(self.sample_passages)

        self.assertIsNotNone(dpr.passage_embeddings)
        self.assertEqual(dpr.passage_embeddings.shape[0], 4)
        self.assertEqual(dpr.passage_embeddings.shape[1], 384)

    @weight(2)
    @number("2.9")
    def test_retrieve_returns_correct_format(self):
        """Test that retrieve returns results in correct format."""
        dpr = SimpleDPR()
        dpr.index_passages(self.sample_passages)
        results = dpr.retrieve("What is machine learning?", top_k=2)

        self.assertEqual(len(results), 2)
        self.assertIn("title", results[0])
        self.assertIn("text", results[0])
        self.assertIn("score", results[0])

    @weight(2)
    @number("2.10")
    def test_retrieve_relevance_ranking(self):
        """Test that retrieve returns relevant passages ranked by score."""
        dpr = SimpleDPR()
        dpr.index_passages(self.sample_passages)
        results = dpr.retrieve("What is machine learning?", top_k=4)

        # Scores should be in descending order
        scores = [r["score"] for r in results]
        self.assertEqual(scores, sorted(scores, reverse=True))

        # The top result should be Machine Learning or Deep Learning (both relevant)
        top_titles = [results[0]["title"], results[1]["title"]]
        self.assertTrue(
            "Machine Learning" in top_titles or "Deep Learning" in top_titles,
            f"Expected 'Machine Learning' or 'Deep Learning' in top results, got {top_titles}"
        )


if __name__ == "__main__":
    unittest.main()
