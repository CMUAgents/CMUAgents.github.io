import random
import unittest
import numpy as np
import torch

from gradescope_utils.autograder_utils.decorators import weight, number

# Set seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

# Force CPU for consistent results with autograder
torch.set_default_device("cpu")

try:
    from programming.rag_sequence import (
        compute_sequence_log_prob,
        marginalize_over_passages,
        rag_sequence_probability,
        log_sum_exp,
    )
except ImportError:
    from rag_sequence import (
        compute_sequence_log_prob,
        marginalize_over_passages,
        rag_sequence_probability,
        log_sum_exp,
    )


class TestComputeSequenceLogProb(unittest.TestCase):
    """Tests for compute_sequence_log_prob function."""

    @weight(2)
    @number("3.1")
    def test_compute_sequence_log_prob_basic(self):
        """Test that compute_sequence_log_prob sums log probabilities."""
        token_log_probs = np.array([-0.5, -0.3, -0.2])
        result = compute_sequence_log_prob(token_log_probs)
        expected = -1.0
        self.assertAlmostEqual(result, expected, places=5)

    @weight(2)
    @number("3.2")
    def test_compute_sequence_log_prob_longer_sequence(self):
        """Test compute_sequence_log_prob with longer sequence."""
        token_log_probs = np.array([-0.1, -0.2, -0.3, -0.4, -0.5])
        result = compute_sequence_log_prob(token_log_probs)
        expected = -1.5
        self.assertAlmostEqual(result, expected, places=5)


class TestMarginalizeOverPassages(unittest.TestCase):
    """Tests for marginalize_over_passages function."""

    @weight(2)
    @number("3.3")
    def test_marginalize_over_passages_basic(self):
        """Test marginalization over passages."""
        passage_log_probs = np.log(np.array([0.5, 0.3, 0.2]))
        sequence_log_probs = np.array([-1.0, -1.5, -2.0])
        result = marginalize_over_passages(passage_log_probs, sequence_log_probs)

        # Manual calculation:
        # p = 0.5 * exp(-1.0) + 0.3 * exp(-1.5) + 0.2 * exp(-2.0)
        expected = np.log(0.5 * np.exp(-1.0) + 0.3 * np.exp(-1.5) + 0.2 * np.exp(-2.0))
        self.assertAlmostEqual(result, expected, places=5)

    @weight(2)
    @number("3.4")
    def test_marginalize_over_passages_uniform(self):
        """Test marginalization with uniform passage probabilities."""
        passage_log_probs = np.log(np.array([0.25, 0.25, 0.25, 0.25]))
        sequence_log_probs = np.array([-1.0, -1.0, -1.0, -1.0])
        result = marginalize_over_passages(passage_log_probs, sequence_log_probs)

        # With uniform probs and equal seq probs: 4 * 0.25 * exp(-1.0) = exp(-1.0)
        expected = -1.0
        self.assertAlmostEqual(result, expected, places=5)


class TestRAGSequenceProbability(unittest.TestCase):
    """Tests for rag_sequence_probability function."""

    @weight(2)
    @number("3.5")
    def test_rag_sequence_probability_basic(self):
        """Test full RAG-Sequence probability computation."""
        passage_log_probs = np.log(np.array([0.5, 0.3, 0.2]))
        token_log_probs = np.array([
            [-0.3, -0.4, -0.2],
            [-0.4, -0.3, -0.5],
            [-0.5, -0.6, -0.4],
        ])
        result = rag_sequence_probability(passage_log_probs, token_log_probs)

        # Manual calculation:
        # seq_probs = [-0.9, -1.2, -1.5] (sum of each row)
        # marginalized = log(0.5*exp(-0.9) + 0.3*exp(-1.2) + 0.2*exp(-1.5))
        seq_log_probs = np.array([-0.9, -1.2, -1.5])
        expected = log_sum_exp(passage_log_probs + seq_log_probs)
        self.assertAlmostEqual(result, expected, places=5)

