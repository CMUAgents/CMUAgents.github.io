import random
import unittest
import numpy as np
import torch

from gradescope_utils.autograder_utils.decorators import weight, number

# Set seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

# Force CPU for consistent results with autograder
torch.set_default_device("cpu")

try:
    from programming.rag_token import (
        marginalize_token_over_passages,
        rag_token_probability,
        log_sum_exp,
    )
except ImportError:
    from rag_token import (
        marginalize_token_over_passages,
        rag_token_probability,
        log_sum_exp,
    )


class TestMarginalizeTokenOverPassages(unittest.TestCase):
    """Tests for marginalize_token_over_passages function."""

    @weight(2)
    @number("4.1")
    def test_marginalize_token_basic(self):
        """Test marginalization of single token over passages."""
        passage_log_probs = np.log(np.array([0.5, 0.3, 0.2]))
        token_log_probs = np.array([-0.3, -0.4, -0.5])
        result = marginalize_token_over_passages(passage_log_probs, token_log_probs)

        # Manual: log(0.5*exp(-0.3) + 0.3*exp(-0.4) + 0.2*exp(-0.5))
        expected = np.log(
            0.5 * np.exp(-0.3) + 0.3 * np.exp(-0.4) + 0.2 * np.exp(-0.5)
        )
        self.assertAlmostEqual(result, expected, places=5)

    @weight(2)
    @number("4.2")
    def test_marginalize_token_uniform(self):
        """Test marginalization with uniform probabilities."""
        passage_log_probs = np.log(np.array([0.5, 0.5]))
        token_log_probs = np.array([-1.0, -1.0])
        result = marginalize_token_over_passages(passage_log_probs, token_log_probs)

        # With uniform: 2 * 0.5 * exp(-1.0) = exp(-1.0)
        expected = -1.0
        self.assertAlmostEqual(result, expected, places=5)


class TestRAGTokenProbability(unittest.TestCase):
    """Tests for rag_token_probability function."""

    @weight(2)
    @number("4.3")
    def test_rag_token_probability_basic(self):
        """Test full RAG-Token probability computation."""
        passage_log_probs = np.log(np.array([0.5, 0.3, 0.2]))
        token_log_probs = np.array([
            [-0.3, -0.4, -0.2],
            [-0.4, -0.3, -0.5],
            [-0.5, -0.6, -0.4],
        ])
        result = rag_token_probability(passage_log_probs, token_log_probs)

        # Manual calculation: marginalize each token, then sum
        marginal_0 = log_sum_exp(passage_log_probs + token_log_probs[:, 0])
        marginal_1 = log_sum_exp(passage_log_probs + token_log_probs[:, 1])
        marginal_2 = log_sum_exp(passage_log_probs + token_log_probs[:, 2])
        expected = marginal_0 + marginal_1 + marginal_2

        self.assertAlmostEqual(result, expected, places=5)

    @weight(2)
    @number("4.4")
    def test_rag_token_vs_sequence_different(self):
        """Test that RAG-Token gives different result than simple averaging."""
        passage_log_probs = np.log(np.array([0.5, 0.3, 0.2]))

        # Different passages are good at different tokens
        token_log_probs = np.array([
            [-0.1, -1.0, -0.1, -1.0],  # Passage 1: good at tokens 0, 2
            [-1.0, -0.1, -1.0, -0.1],  # Passage 2: good at tokens 1, 3
            [-0.5, -0.5, -0.5, -0.5],  # Passage 3: mediocre at all
        ])
        result = rag_token_probability(passage_log_probs, token_log_probs)

        # RAG-Token should be able to leverage different passages for different tokens
        # Result should be better than any single passage's sequence probability
        best_single_passage = max(np.sum(token_log_probs, axis=1))
        self.assertTrue(result > best_single_passage)

    @weight(2)
    @number("4.5")
    def test_rag_token_probability_longer_sequence(self):
        """Test RAG-Token with longer sequence."""
        passage_log_probs = np.log(np.array([0.6, 0.4]))
        token_log_probs = np.array([
            [-0.2, -0.3, -0.2, -0.3, -0.2],
            [-0.3, -0.2, -0.3, -0.2, -0.3],
        ])
        result = rag_token_probability(passage_log_probs, token_log_probs)

        # Verify it's a valid log probability (negative)
        self.assertTrue(result < 0)

        # Verify correct computation
        expected = 0.0
        for i in range(5):
            expected += log_sum_exp(passage_log_probs + token_log_probs[:, i])
        self.assertAlmostEqual(result, expected, places=5)
