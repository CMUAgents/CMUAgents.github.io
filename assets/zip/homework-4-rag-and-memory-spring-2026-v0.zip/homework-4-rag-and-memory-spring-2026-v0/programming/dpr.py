"""
Dense Passage Retrieval (DPR)

A simplified implementation of Dense Passage Retrieval based on:
https://github.com/facebookresearch/DPR

This implementation demonstrates the core concepts of DPR:
1. Preprocessing queries and passages with special tokens
2. Encoding text into dense embeddings using a transformer
3. Building an index of passage embeddings
4. Retrieving relevant passages using dot product similarity
"""

import random
import numpy as np
import torch
from typing import List, Dict, Optional
from sentence_transformers import SentenceTransformer

# Set seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

# Force CPU for consistent results with autograder
# Note: Students may use GPU locally, but tests run on CPU
DEVICE = "cpu"

# Special tokens used in DPR
SEP_TOKEN = "[SEP]"


###############
# Preprocessing
###############

def preprocess_query(query: str) -> str:
    """
    Preprocess a query by appending the [SEP] token.

    In DPR, queries are formatted with a separation token at the end.

    Args:
        query: The raw query string

    Returns:
        The preprocessed query with [SEP] token appended

    Example:
        >>> preprocess_query("What is machine learning?")
        "What is machine learning? [SEP]"
    """
    # Fill in: Return the query with [SEP] token appended
    # Hint: Use an f-string to combine query, a space, and SEP_TOKEN
    pass


def preprocess_passage(title: str, text: str) -> str:
    """
    Preprocess a passage by combining title and text with [SEP] token.

    In DPR, passages are formatted with the title prepended and separated
    from the content using a [SEP] token.

    Args:
        title: The title of the passage (e.g., Wikipedia article title)
        text: The passage text content

    Returns:
        The preprocessed passage with title [SEP] text format

    Example:
        >>> preprocess_passage("Machine Learning", "ML is a field of study...")
        "Machine Learning [SEP] ML is a field of study..."
    """
    # Fill in: Return the title and text combined with [SEP] token
    # Hint: Format should be "title [SEP] text"
    pass


def chunk_document(title: str, text: str, chunk_size: int = 100) -> List[Dict[str, str]]:
    """
    Split a document into chunks of approximately chunk_size words.

    In DPR, long documents (like Wikipedia articles) are split into smaller
    passages of approximately 100 words each. Each chunk retains the original
    title for context.

    Args:
        title: The document title
        text: The full document text
        chunk_size: Target number of words per chunk (default: 100)

    Returns:
        A list of dictionaries, each containing:
            - "title": The original document title
            - "text": The chunk text

    Example:
        >>> chunks = chunk_document("AI", "word " * 250, chunk_size=100)
        >>> len(chunks)
        3
        >>> chunks[0]["title"]
        "AI"
    """
    # Fill in: Split the text into chunks of chunk_size words
    # Step 1: Split text into words
    # Step 2: Loop through words in increments of chunk_size
    # Step 3: Create a dictionary with "title" and "text" for each chunk
    # Step 4: Return the list of chunk dictionaries
    pass


################
# SimpleDPR Class
################

class SimpleDPR:
    """
    A simplified Dense Passage Retriever.

    This class implements the core functionality of DPR:
    - Encoding queries and passages into dense embeddings
    - Building an index of passage embeddings
    - Retrieving top-k relevant passages for a query

    Attributes:
        model: The sentence transformer model for encoding
        passage_embeddings: Numpy array of indexed passage embeddings
        passages: List of indexed passage dictionaries
    """

    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """
        Initialize the SimpleDPR retriever.

        Args:
            model_name: HuggingFace model name for the encoder
        """
        print(f"Loading model {model_name}...")
        self.model = SentenceTransformer(model_name, device=DEVICE)
        self.passage_embeddings: Optional[np.ndarray] = None
        self.passages: List[Dict[str, str]] = []

    def encode(self, texts: List[str]) -> np.ndarray:
        """
        Encode a list of texts into dense embeddings.

        Uses the sentence transformer model to generate embeddings.
        The embeddings come from the [CLS] token representation.

        Args:
            texts: List of text strings to encode

        Returns:
            Numpy array of shape (len(texts), embedding_dim)

        Example:
            >>> dpr = SimpleDPR()
            >>> embeddings = dpr.encode(["Hello world", "Test query"])
            >>> embeddings.shape
            (2, 384)
        """
        # Fill in: Use self.model.encode() to encode the texts
        # Hint: Pass convert_to_numpy=True to get a numpy array
        pass

    def index_passages(self, passages: List[Dict[str, str]]) -> None:
        """
        Build an index of passage embeddings for retrieval.

        Preprocesses each passage (adding title [SEP] text format),
        encodes them into embeddings, and stores them for later retrieval.

        Args:
            passages: List of passage dictionaries, each containing:
                - "title": The passage title
                - "text": The passage content

        Example:
            >>> dpr = SimpleDPR()
            >>> passages = [
            ...     {"title": "AI", "text": "Artificial intelligence is..."},
            ...     {"title": "ML", "text": "Machine learning is..."}
            ... ]
            >>> dpr.index_passages(passages)
        """
        # Fill in: Index the passages for later retrieval
        # Step 1: Store passages in self.passages
        # Step 2: Preprocess each passage using preprocess_passage()
        # Step 3: Encode all preprocessed passages using self.encode()
        # Step 4: Store embeddings in self.passage_embeddings
        pass

    def retrieve(self, query: str, top_k: int = 5) -> List[Dict]:
        """
        Retrieve the top-k most relevant passages for a query.

        Encodes the query, computes dot product similarity with all
        indexed passages, and returns the top-k results.

        Args:
            query: The search query string
            top_k: Number of passages to retrieve (default: 5)

        Returns:
            List of dictionaries, each containing:
                - "title": The passage title
                - "text": The passage content
                - "score": The similarity score (dot product)

        Raises:
            ValueError: If no passages have been indexed

        Example:
            >>> dpr = SimpleDPR()
            >>> dpr.index_passages([...])
            >>> results = dpr.retrieve("What is AI?", top_k=3)
            >>> results[0]["title"]
            "Artificial Intelligence"
        """
        if self.passage_embeddings is None or len(self.passages) == 0:
            raise ValueError("No passages indexed. Call index_passages first.")

        # Fill in: Retrieve top-k passages for the query
        # Step 1: Preprocess the query using preprocess_query()
        # Step 2: Encode the query using self.encode() (returns array, get first element)
        # Step 3: Compute dot product similarity: np.dot(self.passage_embeddings, query_embedding)
        # Step 4: Get top-k indices using np.argsort() (remember to reverse for descending order)
        # Step 5: Build and return results list with "title", "text", and "score" for each
        pass


if __name__ == "__main__":
    # Example usage
    print("=== Dense Passage Retrieval Demo ===\n")

    # Sample passages (simplified Wikipedia-style)
    sample_passages = [
        {
            "title": "Machine Learning",
            "text": "Machine learning is a subset of artificial intelligence that enables systems to learn and improve from experience without being explicitly programmed. It focuses on developing computer programs that can access data and use it to learn for themselves."
        },
        {
            "title": "Deep Learning",
            "text": "Deep learning is a type of machine learning based on artificial neural networks with multiple layers. These networks attempt to simulate the behavior of the human brain in processing data and creating patterns for decision making."
        },
        {
            "title": "Natural Language Processing",
            "text": "Natural language processing is a field of artificial intelligence that gives machines the ability to read, understand, and derive meaning from human languages. It combines computational linguistics with machine learning."
        },
        {
            "title": "Computer Vision",
            "text": "Computer vision is a field of artificial intelligence that trains computers to interpret and understand the visual world. Using digital images and deep learning models, machines can identify and classify objects."
        },
        {
            "title": "Reinforcement Learning",
            "text": "Reinforcement learning is an area of machine learning where an agent learns to make decisions by taking actions in an environment to maximize cumulative reward. It differs from supervised learning by not requiring labeled data."
        }
    ]

    # Initialize DPR
    dpr = SimpleDPR()

    # Index passages
    print("Indexing passages...")
    dpr.index_passages(sample_passages)
    print(f"Indexed {len(sample_passages)} passages\n")

    # Test queries
    queries = [
        "What is machine learning?",
        "How do neural networks work?",
        "What is NLP used for?"
    ]

    for query in queries:
        print(f"Query: {query}")
        print("-" * 50)
        results = dpr.retrieve(query, top_k=3)
        for i, result in enumerate(results, 1):
            print(f"  {i}. [{result['title']}] (score: {result['score']:.4f})")
            print(f"     {result['text'][:100]}...")
        print()
