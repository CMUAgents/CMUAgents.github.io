"""
RAG-Sequence Implementation

This module implements the RAG-Sequence model from:
"Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks"
(Lewis et al., 2020)

RAG-Sequence treats the retrieved document as a single latent variable that is
marginalized over to get the seq2seq probability. The same document is used to
generate the entire sequence:

p_RAG-Sequence(y|x) ≈ Σ_{z ∈ top-k} p(z|x) * Π_i p(y_i|x,z,y_{1:i-1})

Key insight: The sum over passages is OUTSIDE the product over tokens.
This means each passage generates a complete sequence independently.
"""

import random
import numpy as np
import torch
from typing import List, Dict, Tuple

# Set seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

# Force CPU for consistent results with autograder
DEVICE = "cpu"


def compute_sequence_log_prob(
    token_log_probs: np.ndarray
) -> float:
    """
    Compute the log probability of a sequence given per-token log probabilities.

    In RAG-Sequence, we need to compute Π_i p(y_i|x,z,y_{1:i-1}) for each passage.
    In log space, this becomes: Σ_i log p(y_i|x,z,y_{1:i-1})

    Args:
        token_log_probs: Array of shape (seq_len,) containing log p(y_i|x,z,y_{1:i-1})
                        for each token in the sequence

    Returns:
        The log probability of the entire sequence: log Π_i p(y_i|...)

    Example:
        >>> token_log_probs = np.array([-0.5, -0.3, -0.2])  # log probs for 3 tokens
        >>> compute_sequence_log_prob(token_log_probs)
        -1.0
    """
    # Fill in: Sum the log probabilities to get sequence log probability
    # Hint: In log space, multiplication becomes addition
    pass


def log_sum_exp(log_probs: np.ndarray) -> float:
    """
    Compute log(sum(exp(log_probs))) in a numerically stable way.

    Uses the log-sum-exp trick: log Σ exp(x_i) = max(x) + log Σ exp(x_i - max(x))

    Args:
        log_probs: Array of log probabilities

    Returns:
        log(sum(exp(log_probs)))
    """
    max_log_prob = np.max(log_probs)
    return max_log_prob + np.log(np.sum(np.exp(log_probs - max_log_prob)))


def marginalize_over_passages(
    passage_log_probs: np.ndarray,
    sequence_log_probs: np.ndarray
) -> float:
    """
    Marginalize over passages to get the final RAG-Sequence probability.

    Implements: p(y|x) = Σ_z p(z|x) * p(y|x,z)

    In log space, we need to use the log-sum-exp trick:
    log p(y|x) = log Σ_z exp(log p(z|x) + log p(y|x,z))

    Args:
        passage_log_probs: Array of shape (k,) containing log p(z|x) for each
                          of the k retrieved passages
        sequence_log_probs: Array of shape (k,) containing log p(y|x,z) for each
                           passage (the sequence probability given that passage)

    Returns:
        The marginalized log probability: log Σ_z p(z|x) * p(y|x,z)

    Example:
        >>> passage_log_probs = np.array([-0.5, -1.0, -1.5])  # 3 passages
        >>> sequence_log_probs = np.array([-2.0, -1.5, -3.0])  # seq prob per passage
        >>> result = marginalize_over_passages(passage_log_probs, sequence_log_probs)
    """
    # Fill in: Implement marginalization over passages
    # Step 1: Combine passage and sequence log probs (add them)
    # Step 2: Use log_sum_exp for numerical stability
    # Hint: log p(z|x) + log p(y|x,z) = log(p(z|x) * p(y|x,z))
    pass


def rag_sequence_probability(
    passage_log_probs: np.ndarray,
    token_log_probs_per_passage: np.ndarray
) -> float:
    """
    Compute the RAG-Sequence probability for a generated sequence.

    Implements the full RAG-Sequence formula:
    p_RAG-Sequence(y|x) ≈ Σ_{z ∈ top-k} p(z|x) * Π_i p(y_i|x,z,y_{1:i-1})

    Args:
        passage_log_probs: Array of shape (k,) containing log p(z|x) for each
                          of the k retrieved passages
        token_log_probs_per_passage: Array of shape (k, seq_len) containing
                                     log p(y_i|x,z,y_{1:i-1}) for each passage
                                     and each token position

    Returns:
        The RAG-Sequence log probability for the sequence

    Example:
        >>> # 3 passages, sequence length 4
        >>> passage_log_probs = np.array([-0.5, -1.0, -1.5])
        >>> token_log_probs = np.array([
        ...     [-0.3, -0.4, -0.2, -0.5],  # passage 1
        ...     [-0.2, -0.3, -0.4, -0.3],  # passage 2
        ...     [-0.5, -0.6, -0.3, -0.4],  # passage 3
        ... ])
        >>> prob = rag_sequence_probability(passage_log_probs, token_log_probs)
    """
    # Fill in: Implement the full RAG-Sequence probability computation
    # Step 1: For each passage, compute the sequence log probability
    #         using compute_sequence_log_prob
    # Step 2: Marginalize over passages using marginalize_over_passages
    pass


def select_best_sequence(
    passage_log_probs: np.ndarray,
    candidate_sequences: List[List[str]],
    token_log_probs_per_sequence: List[np.ndarray]
) -> Tuple[List[str], float]:
    """
    Select the best sequence from multiple candidates using RAG-Sequence scoring.

    In practice, RAG-Sequence generates multiple candidate sequences (one per
    passage) and selects the one with the highest marginalized probability.

    Args:
        passage_log_probs: Array of shape (k,) with retrieval log probs
        candidate_sequences: List of k candidate token sequences
        token_log_probs_per_sequence: List of k arrays, each of shape (k, seq_len)
                                      containing token log probs for that candidate
                                      evaluated against each passage

    Returns:
        Tuple of (best_sequence, best_log_prob)
    """
    best_sequence = None
    best_log_prob = float('-inf')

    for i, (sequence, token_log_probs) in enumerate(
        zip(candidate_sequences, token_log_probs_per_sequence)
    ):
        log_prob = rag_sequence_probability(passage_log_probs, token_log_probs)

        if log_prob > best_log_prob:
            best_log_prob = log_prob
            best_sequence = sequence

    return best_sequence, best_log_prob


if __name__ == "__main__":
    print("=== RAG-Sequence Demo ===\n")

    # Example: 3 retrieved passages with their retrieval probabilities
    # These would come from the retriever (e.g., DPR)
    passage_probs = np.array([0.5, 0.3, 0.2])  # Must sum to 1
    passage_log_probs = np.log(passage_probs)

    print(f"Passage probabilities: {passage_probs}")
    print(f"Passage log probs: {passage_log_probs}\n")

    # Example: Token-level generation probabilities for a 4-token sequence
    # Shape: (num_passages, seq_len)
    # These would come from the generator (e.g., BART)
    token_probs_per_passage = np.array([
        [0.7, 0.6, 0.8, 0.5],  # Passage 1: good at generating this sequence
        [0.5, 0.7, 0.6, 0.6],  # Passage 2: moderate
        [0.3, 0.4, 0.5, 0.4],  # Passage 3: poor fit
    ])
    token_log_probs_per_passage = np.log(token_probs_per_passage)

    print("Token probabilities per passage:")
    for i, probs in enumerate(token_probs_per_passage):
        print(f"  Passage {i+1}: {probs}")
    print()

    # Compute RAG-Sequence probability
    result = rag_sequence_probability(passage_log_probs, token_log_probs_per_passage)
    print(f"RAG-Sequence log probability: {result:.4f}")
    print(f"RAG-Sequence probability: {np.exp(result):.4f}")
