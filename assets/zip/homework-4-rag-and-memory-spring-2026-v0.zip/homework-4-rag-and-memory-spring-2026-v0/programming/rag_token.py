"""
RAG-Token Implementation

This module implements the RAG-Token model from:
"Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks"
(Lewis et al., 2020)

RAG-Token allows different documents to be used for each token in the generated
sequence. It marginalizes over passages at each token position:

p_RAG-Token(y|x) ≈ Π_i Σ_{z ∈ top-k} p(z|x) * p(y_i|x,z,y_{1:i-1})

Key insight: The sum over passages is INSIDE the product over tokens.
This allows the model to "switch" between passages during generation.
"""

import random
import numpy as np
import torch
from typing import List, Dict

# Set seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

# Force CPU for consistent results with autograder
DEVICE = "cpu"


def log_sum_exp(log_probs: np.ndarray) -> float:
    """
    Compute log(sum(exp(log_probs))) in a numerically stable way.

    Uses the log-sum-exp trick: log Σ exp(x_i) = max(x) + log Σ exp(x_i - max(x))

    Args:
        log_probs: Array of log probabilities

    Returns:
        log(sum(exp(log_probs)))
    """
    max_log_prob = np.max(log_probs)
    return max_log_prob + np.log(np.sum(np.exp(log_probs - max_log_prob)))


def marginalize_token_over_passages(
    passage_log_probs: np.ndarray,
    token_log_probs: np.ndarray
) -> float:
    """
    Marginalize a single token's probability over all passages.

    Implements: p(y_i|x,y_{1:i-1}) = Σ_z p(z|x) * p(y_i|x,z,y_{1:i-1})

    In log space: log p(y_i|...) = log Σ_z exp(log p(z|x) + log p(y_i|x,z,...))

    Args:
        passage_log_probs: Array of shape (k,) containing log p(z|x) for each
                          of the k retrieved passages
        token_log_probs: Array of shape (k,) containing log p(y_i|x,z,y_{1:i-1})
                        for each passage at this token position

    Returns:
        The marginalized log probability for this token

    Example:
        >>> passage_log_probs = np.array([-0.5, -1.0, -1.5])  # 3 passages
        >>> token_log_probs = np.array([-0.3, -0.4, -0.5])    # token prob per passage
        >>> result = marginalize_token_over_passages(passage_log_probs, token_log_probs)
    """
    # Fill in: Marginalize this token's probability over all passages
    # Step 1: Combine passage and token log probs (add them)
    # Step 2: Use log_sum_exp to compute the marginalized probability
    # Hint: This is similar to marginalize_over_passages in rag_sequence.py
    #       but operates on a single token instead of a whole sequence
    pass


def rag_token_probability(
    passage_log_probs: np.ndarray,
    token_log_probs_per_passage: np.ndarray
) -> float:
    """
    Compute the RAG-Token probability for a generated sequence.

    Implements the full RAG-Token formula:
    p_RAG-Token(y|x) ≈ Π_i Σ_{z ∈ top-k} p(z|x) * p(y_i|x,z,y_{1:i-1})

    Args:
        passage_log_probs: Array of shape (k,) containing log p(z|x) for each
                          of the k retrieved passages
        token_log_probs_per_passage: Array of shape (k, seq_len) containing
                                     log p(y_i|x,z,y_{1:i-1}) for each passage
                                     and each token position

    Returns:
        The RAG-Token log probability for the sequence

    Example:
        >>> # 3 passages, sequence length 4
        >>> passage_log_probs = np.array([-0.5, -1.0, -1.5])
        >>> token_log_probs = np.array([
        ...     [-0.3, -0.4, -0.2, -0.5],  # passage 1
        ...     [-0.2, -0.3, -0.4, -0.3],  # passage 2
        ...     [-0.5, -0.6, -0.3, -0.4],  # passage 3
        ... ])
        >>> prob = rag_token_probability(passage_log_probs, token_log_probs)
    """
    # Fill in: Implement the full RAG-Token probability computation
    # Step 1: Get the shape (k passages, seq_len tokens)
    # Step 2: For each token position i:
    #         a) Extract token log probs at position i for all passages
    #         b) Marginalize over passages using marginalize_token_over_passages
    # Step 3: Sum all marginalized log probs (product in prob space = sum in log space)
    # Hint: The key difference from RAG-Sequence is that marginalization happens
    #       PER TOKEN, not per sequence
    pass


def compute_token_weights(
    passage_log_probs: np.ndarray,
    token_log_probs_per_passage: np.ndarray
) -> np.ndarray:
    """
    Compute the effective weight of each passage for each token position.

    This shows which passage is most influential for generating each token.
    Useful for interpreting RAG-Token's behavior.

    Args:
        passage_log_probs: Array of shape (k,) with retrieval log probs
        token_log_probs_per_passage: Array of shape (k, seq_len) with token log probs

    Returns:
        Array of shape (k, seq_len) with normalized weights per token position
    """
    k, seq_len = token_log_probs_per_passage.shape
    weights = np.zeros((k, seq_len))

    for i in range(seq_len):
        # Combine passage probs with token probs for this position
        combined = passage_log_probs + token_log_probs_per_passage[:, i]

        # Normalize to get weights (softmax in log space)
        weights[:, i] = np.exp(combined - log_sum_exp(combined))

    return weights


if __name__ == "__main__":
    print("=== RAG-Token Demo ===\n")

    # Example: 3 retrieved passages with their retrieval probabilities
    passage_probs = np.array([0.5, 0.3, 0.2])
    passage_log_probs = np.log(passage_probs)

    print(f"Passage probabilities: {passage_probs}")
    print(f"Passage log probs: {passage_log_probs}\n")

    # Example: Token-level generation probabilities for a 4-token sequence
    # Notice how different passages are better for different tokens
    token_probs_per_passage = np.array([
        [0.8, 0.3, 0.7, 0.4],  # Passage 1: good at tokens 0, 2
        [0.3, 0.8, 0.4, 0.7],  # Passage 2: good at tokens 1, 3
        [0.4, 0.4, 0.5, 0.5],  # Passage 3: moderate overall
    ])
    token_log_probs_per_passage = np.log(token_probs_per_passage)

    print("Token probabilities per passage:")
    for i, probs in enumerate(token_probs_per_passage):
        print(f"  Passage {i+1}: {probs}")
    print()

    # Compute RAG-Token probability
    result = rag_token_probability(passage_log_probs, token_log_probs_per_passage)
    print(f"RAG-Token log probability: {result:.4f}")
    print(f"RAG-Token probability: {np.exp(result):.4f}")

    # Show passage weights per token
    weights = compute_token_weights(passage_log_probs, token_log_probs_per_passage)
    print("\nPassage weights per token position:")
    print("(Shows which passage influences each token)")
    for i, w in enumerate(weights):
        print(f"  Passage {i+1}: {np.round(w, 3)}")
