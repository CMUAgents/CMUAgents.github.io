import numpy as np
import faiss


def create_flat_l2_index(d: int) -> faiss.IndexFlatL2:
    """Create a flat L2 (Euclidean distance) FAISS index with dimension d."""
    # TODO: implement


def create_flat_ip_index(d: int) -> faiss.IndexFlatIP:
    """Create a flat inner product FAISS index with dimension d."""
    # TODO: implement


def get_index_dimension(index: faiss.Index) -> int:
    """Return the number of dimensions of the index."""
    # TODO: implement


def is_index_trained(index: faiss.Index) -> bool:
    """Return True if the index is trained and ready for use."""
    # TODO: implement


def add_vectors(index: faiss.Index, vectors: np.ndarray) -> None:
    """Add vectors (shape: n x d, dtype: float32) to the index."""
    # TODO: implement


def get_index_size(index: faiss.Index) -> int:
    """Return the number of vectors currently stored in the index."""
    # TODO: implement


def search_index(index: faiss.Index, query_vectors: np.ndarray, k: int):
    """
    Search for k nearest neighbors for each query vector.
    query_vectors: shape (n_queries, d), dtype float32
    Returns (distances, indices), each of shape (n_queries, k).
    """
    # TODO: implement


def find_nearest_neighbor(index: faiss.Index, query_vector: np.ndarray) -> int:
    """
    Find the index of the single nearest neighbor for a query vector.
    query_vector: shape (1, d), dtype float32
    Returns the integer index of the nearest neighbor.
    """
    # TODO: implement


def normalize_vectors(vectors: np.ndarray) -> np.ndarray:
    """
    Normalize vectors in-place using L2 normalization.
    vectors: shape (n, d), dtype float32
    Returns the normalized vectors.
    """
    # TODO: implement


def build_l2_index(d: int, vectors: np.ndarray) -> faiss.IndexFlatL2:
    """
    Create a flat L2 index with dimension d and add vectors to it.
    vectors: shape (n, d), dtype float32
    Returns the populated index.
    """
    # TODO: implement


def get_nearest_distances(index: faiss.Index, query_vector: np.ndarray, k: int) -> np.ndarray:
    """
    Return the distances to the k nearest neighbors for a single query vector.
    query_vector: shape (1, d), dtype float32
    Returns a 1D array of k distances.
    """
    # TODO: implement


def exact_match_distance(index: faiss.Index, vector: np.ndarray) -> float:
    """
    Search the index for the given vector and return the distance to its nearest neighbor.
    vector: shape (1, d), dtype float32
    If the vector exists in the index, this should return approximately 0.0.
    """
    # TODO: implement


def create_ivf_index(d: int, nlist: int) -> faiss.IndexIVFFlat:
    """
    Create an IVF flat index with dimension d and nlist clusters (L2 metric).
    Hint: you will need a quantizer (IndexFlatL2) and faiss.METRIC_L2.
    Returns an untrained IVF flat index.
    """
    # TODO: implement


def save_index(index: faiss.Index, filepath: str) -> None:
    """Save a FAISS index to a file at the given filepath."""
    # TODO: implement


def load_index(filepath: str) -> faiss.Index:
    """Load and return a FAISS index from a file at the given filepath."""
    # TODO: implement
