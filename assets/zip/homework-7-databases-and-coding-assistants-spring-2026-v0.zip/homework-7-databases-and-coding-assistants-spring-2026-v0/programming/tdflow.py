MODEL_NAME = "Qwen/Qwen2-1.5B-Instruct"

_gen = None


def _load_model():
    """Lazy-load the model on first call to generate()."""
    global _gen
    if _gen is not None:
        return
    import torch
    import transformers
    from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline, GenerationConfig

    transformers.logging.set_verbosity_error()
    torch.manual_seed(42)

    print(f"Loading model {MODEL_NAME} ...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, use_fast=True)
    model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, device_map="cpu", torch_dtype="auto")
    _gen = pipeline(
        "text-generation",
        model=model,
        tokenizer=tokenizer,
        device_map="cpu",
        return_full_text=False,
    )


def generate(prompt: str) -> str:
    """Call the local LLM and return the response text. Do not modify this function."""
    from transformers import GenerationConfig
    _load_model()
    generation_config = GenerationConfig(max_new_tokens=256, do_sample=False)
    out = _gen(prompt, generation_config=generation_config)
    return out[0]["generated_text"]


def generate_tests(issue: str) -> list[str]:
    """
    Generate reproduction tests for a GitHub issue.

    Call generate() with an appropriate prompt and parse the response into a
    list of test strings (one test per element).

    Args:
        issue: The GitHub issue description.

    Returns:
        A list of test strings, where each element is a test function as a string.
    """
    # TODO: implement


def explore_files(issue: str, failing_tests: list[str], debug_reports: list[str]) -> str:
    """
    Propose a patch to fix the issue given failing tests and debug reports.

    On the first iteration debug_reports will be empty. On subsequent
    iterations it will contain one report per failing test from debug_one.
    Call generate() with an appropriate prompt and return the patch string.

    Args:
        issue: The GitHub issue description.
        failing_tests: List of failing test source code strings.
        debug_reports: List of debug reports from debug_one (empty on first call).

    Returns:
        A patch string (unified diff format).
    """
    # TODO: implement


def debug_one(test_source: str, test_message: str, issue: str, patch: str) -> str:
    """
    Debug a single failing test and produce a report.

    Call generate() with an appropriate prompt describing the failing test,
    the error message, the issue, and the patch. Return the report as a string.

    Args:
        test_source: Source code of the failing test.
        test_message: Error message produced when running the test.
        issue: The GitHub issue description.
        patch: The patch that was applied but caused the test to fail.

    Returns:
        A debug report string describing the root cause of the failure.
    """
    # TODO: implement


def revise_patch(patch: str, error_message: str) -> str:
    """
    Revise a malformed patch that failed to apply.

    Call generate() with an appropriate prompt explaining the bad patch and
    the error. Return the revised patch string. Do not modify the inserted
    code — only fix the surrounding context lines.

    Args:
        patch: The malformed patch string.
        error_message: The error message from the failed patch application.

    Returns:
        A revised patch string with corrected context lines.
    """
    # TODO: implement


def tdflow(issue: str, tests: list[str] = None, max_iterations: int = 3) -> str:
    """
    Run the simplified TDFlow agentic loop.

    Steps:
      1. If tests is None or empty, call generate_tests to produce them.
      2. For up to max_iterations:
           a. Call explore_files to propose a patch.
           b. Call revise_patch to validate / fix the patch.
           c. Call debug_one for each test and collect reports.
      3. Return the final patch string.

    Args:
        issue: The GitHub issue description.
        tests: Optional list of reproduction test strings. If None or empty,
               generate_tests will be called to produce them.
        max_iterations: Maximum number of patch-debug iterations.

    Returns:
        The final patch string.
    """
    # TODO: implement using generate_tests, explore_files, debug_one, revise_patch
