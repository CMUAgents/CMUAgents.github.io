import os
import tempfile
import unittest

import faiss
import numpy as np
from gradescope_utils.autograder_utils.decorators import number, weight

try:
    from programming.similarity_search import (
        add_vectors,
        build_l2_index,
        create_flat_ip_index,
        create_flat_l2_index,
        create_ivf_index,
        exact_match_distance,
        find_nearest_neighbor,
        get_index_dimension,
        get_index_size,
        get_nearest_distances,
        is_index_trained,
        load_index,
        normalize_vectors,
        save_index,
        search_index,
    )
except ImportError:
    from similarity_search import (
        add_vectors,
        build_l2_index,
        create_flat_ip_index,
        create_flat_l2_index,
        create_ivf_index,
        exact_match_distance,
        find_nearest_neighbor,
        get_index_dimension,
        get_index_size,
        get_nearest_distances,
        is_index_trained,
        load_index,
        normalize_vectors,
        save_index,
        search_index,
    )


class TestSimilaritySearch(unittest.TestCase):
    def setUp(self):
        self.d = 8
        np.random.seed(42)
        self.vectors = np.random.rand(10, self.d).astype(np.float32)
        self.query = self.vectors[0:1]

    @weight(3)
    @number("1.1")
    def test_create_flat_l2_index(self):
        """Test that create_flat_l2_index returns an IndexFlatL2 with correct dimension."""
        index = create_flat_l2_index(self.d)
        self.assertIsInstance(index, faiss.IndexFlatL2)
        self.assertEqual(index.d, self.d)

    @weight(3)
    @number("1.2")
    def test_create_flat_ip_index(self):
        """Test that create_flat_ip_index returns an IndexFlatIP with correct dimension."""
        index = create_flat_ip_index(self.d)
        self.assertIsInstance(index, faiss.IndexFlatIP)
        self.assertEqual(index.d, self.d)

    @weight(3)
    @number("1.3")
    def test_get_index_dimension(self):
        """Test that get_index_dimension returns the correct dimension."""
        index = faiss.IndexFlatL2(self.d)
        self.assertEqual(get_index_dimension(index), self.d)

    @weight(3)
    @number("1.4")
    def test_is_index_trained(self):
        """Test that flat indexes report as trained."""
        index = faiss.IndexFlatL2(self.d)
        self.assertTrue(is_index_trained(index))

    @weight(3)
    @number("1.5")
    def test_add_vectors(self):
        """Test that add_vectors adds vectors to the index."""
        index = faiss.IndexFlatL2(self.d)
        add_vectors(index, self.vectors)
        self.assertEqual(index.ntotal, len(self.vectors))

    @weight(3)
    @number("1.6")
    def test_get_index_size(self):
        """Test that get_index_size returns the number of vectors in the index."""
        index = faiss.IndexFlatL2(self.d)
        index.add(self.vectors)
        self.assertEqual(get_index_size(index), len(self.vectors))

    @weight(3)
    @number("1.7")
    def test_search_index(self):
        """Test that search_index returns distances and indices of correct shape."""
        index = faiss.IndexFlatL2(self.d)
        index.add(self.vectors)
        k = 3
        distances, indices = search_index(index, self.query, k)
        self.assertEqual(distances.shape, (1, k))
        self.assertEqual(indices.shape, (1, k))

    @weight(3)
    @number("1.8")
    def test_find_nearest_neighbor(self):
        """Test that find_nearest_neighbor returns the index of the nearest vector."""
        index = faiss.IndexFlatL2(self.d)
        index.add(self.vectors)
        # query is vectors[0], so the nearest neighbor should be index 0
        result = find_nearest_neighbor(index, self.query)
        self.assertEqual(result, 0)

    @weight(3)
    @number("1.9")
    def test_normalize_vectors(self):
        """Test that normalize_vectors produces unit-length vectors."""
        vectors = self.vectors.copy()
        normalized = normalize_vectors(vectors)
        norms = np.linalg.norm(normalized, axis=1)
        np.testing.assert_allclose(norms, np.ones(len(normalized)), atol=1e-6)

    @weight(3)
    @number("1.10")
    def test_build_l2_index(self):
        """Test that build_l2_index returns an IndexFlatL2 populated with vectors."""
        index = build_l2_index(self.d, self.vectors)
        self.assertIsInstance(index, faiss.IndexFlatL2)
        self.assertEqual(index.ntotal, len(self.vectors))

    @weight(3)
    @number("1.11")
    def test_get_nearest_distances(self):
        """Test that get_nearest_distances returns k distances."""
        index = faiss.IndexFlatL2(self.d)
        index.add(self.vectors)
        k = 4
        distances = get_nearest_distances(index, self.query, k)
        self.assertEqual(len(distances), k)

    @weight(3)
    @number("1.12")
    def test_exact_match_distance(self):
        """Test that exact_match_distance returns ~0 for a vector in the index."""
        index = faiss.IndexFlatL2(self.d)
        index.add(self.vectors)
        dist = exact_match_distance(index, self.query)
        self.assertAlmostEqual(dist, 0.0, places=5)

    @weight(3)
    @number("1.13")
    def test_create_ivf_index(self):
        """Test that create_ivf_index returns an untrained IndexIVFFlat with correct properties."""
        nlist = 4
        index = create_ivf_index(self.d, nlist)
        self.assertIsInstance(index, faiss.IndexIVFFlat)
        self.assertEqual(index.d, self.d)
        self.assertFalse(index.is_trained)

    @weight(3)
    @number("1.14")
    def test_save_index(self):
        """Test that save_index writes a non-empty file to the given path."""
        index = faiss.IndexFlatL2(self.d)
        index.add(self.vectors)
        with tempfile.NamedTemporaryFile(suffix=".index", delete=False) as f:
            path = f.name
        try:
            save_index(index, path)
            self.assertTrue(os.path.exists(path))
            self.assertGreater(os.path.getsize(path), 0)
        finally:
            os.unlink(path)

    @weight(3)
    @number("1.15")
    def test_load_index(self):
        """Test that load_index loads a saved index with correct size and dimension."""
        index = faiss.IndexFlatL2(self.d)
        index.add(self.vectors)
        with tempfile.NamedTemporaryFile(suffix=".index", delete=False) as f:
            path = f.name
        try:
            faiss.write_index(index, path)
            loaded = load_index(path)
            self.assertEqual(loaded.ntotal, index.ntotal)
            self.assertEqual(loaded.d, index.d)
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
