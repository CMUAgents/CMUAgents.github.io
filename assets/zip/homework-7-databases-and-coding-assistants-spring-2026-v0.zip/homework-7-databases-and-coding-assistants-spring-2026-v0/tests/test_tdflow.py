import unittest
from unittest.mock import patch

from gradescope_utils.autograder_utils.decorators import number, weight

try:
    from programming.tdflow import debug_one, explore_files, generate_tests, revise_patch, tdflow
    TDFLOW_MODULE = "programming.tdflow"
except ImportError:
    from tdflow import debug_one, explore_files, generate_tests, revise_patch, tdflow
    TDFLOW_MODULE = "tdflow"


MOCK_ISSUE = "The calculate() function raises ZeroDivisionError when given 0."
MOCK_TEST = "def test_calculate_zero():\n    assert calculate(0) == 0"
MOCK_PATCH = "--- a/calc.py\n+++ b/calc.py\n@@ -1,3 +1,3 @@\n-    return a / b\n+    return a / b if b != 0 else 0"
MOCK_REPORT = "Root cause: calculate() does not guard against division by zero."


class TestTDFlow(unittest.TestCase):

    @weight(6)
    @number("3.1")
    def test_generate_tests_returns_list(self):
        """Test that generate_tests returns a non-empty list of strings."""
        with patch(f"{TDFLOW_MODULE}.generate", return_value=MOCK_TEST):
            result = generate_tests(MOCK_ISSUE)
        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)
        self.assertTrue(all(isinstance(t, str) for t in result))

    @weight(6)
    @number("3.2")
    def test_explore_files_returns_str(self):
        """Test that explore_files returns a non-empty string."""
        with patch(f"{TDFLOW_MODULE}.generate", return_value=MOCK_PATCH):
            result = explore_files(
                issue=MOCK_ISSUE,
                failing_tests=[MOCK_TEST],
                debug_reports=[],
            )
        self.assertIsInstance(result, str)
        self.assertGreater(len(result), 0)

    @weight(6)
    @number("3.3")
    def test_debug_one_returns_str(self):
        """Test that debug_one returns a non-empty string."""
        with patch(f"{TDFLOW_MODULE}.generate", return_value=MOCK_REPORT):
            result = debug_one(
                test_source=MOCK_TEST,
                test_message="ZeroDivisionError: division by zero",
                issue=MOCK_ISSUE,
                patch=MOCK_PATCH,
            )
        self.assertIsInstance(result, str)
        self.assertGreater(len(result), 0)

    @weight(6)
    @number("3.4")
    def test_revise_patch_returns_str(self):
        """Test that revise_patch returns a non-empty string."""
        with patch(f"{TDFLOW_MODULE}.generate", return_value=MOCK_PATCH):
            result = revise_patch(
                patch=MOCK_PATCH,
                error_message="patch does not apply",
            )
        self.assertIsInstance(result, str)
        self.assertGreater(len(result), 0)

    @weight(6)
    @number("3.5")
    def test_tdflow_calls_all_agents(self):
        """Test that tdflow runs and calls all four sub-agents."""
        with patch(f"{TDFLOW_MODULE}.generate_tests", return_value=[MOCK_TEST]) as mock_gt, \
             patch(f"{TDFLOW_MODULE}.explore_files", return_value=MOCK_PATCH) as mock_ef, \
             patch(f"{TDFLOW_MODULE}.debug_one", return_value=MOCK_REPORT) as mock_do, \
             patch(f"{TDFLOW_MODULE}.revise_patch", return_value=MOCK_PATCH) as mock_rp:
            result = tdflow(issue=MOCK_ISSUE, tests=None, max_iterations=1)

        self.assertIsInstance(result, str)
        mock_gt.assert_called()
        mock_ef.assert_called()
        mock_do.assert_called()
        mock_rp.assert_called()


if __name__ == "__main__":
    unittest.main()
