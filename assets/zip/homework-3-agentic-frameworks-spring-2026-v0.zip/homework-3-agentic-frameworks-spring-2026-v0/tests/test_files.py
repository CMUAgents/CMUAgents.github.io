import unittest
from gradescope_utils.autograder_utils.decorators import weight
from gradescope_utils.autograder_utils.files import check_submitted_files


class TestFiles(unittest.TestCase):
    @weight(5)
    def test_langchain_example_submitted(self):
        """Check langchain_example.py submitted"""
        missing_files = check_submitted_files(['langchain_example.py'])
        for path in missing_files:
            print('Missing {0}'.format(path))
        self.assertEqual(len(missing_files), 0, 'Missing langchain_example.py!')
        print('langchain_example.py submitted!')

    @weight(5)
    def test_mcp_example_submitted(self):
        """Check mcp_example.py submitted"""
        missing_files = check_submitted_files(['mcp_example.py'])
        for path in missing_files:
            print('Missing {0}'.format(path))
        self.assertEqual(len(missing_files), 0, 'Missing mcp_example.py!')
        print('mcp_example.py submitted!')
