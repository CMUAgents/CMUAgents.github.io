"""
LangChain Example - Exploring LangChain Modules

NOTE: This starter code was developed using Python 3.14 and LangChain 1.2.9.
Depending on your Python version, you may need to adjust imports or install
different packages. Refer to the LangChain documentation for your version.

In this exercise, you will create a LangChain application that demonstrates
the use of all six core modules:
    1. Agents - langchain.agents
    2. Middleware - langchain.agents.middleware
    3. Models - langchain.chat_models (or langchain_huggingface for local models)
    4. Messages - langchain.messages
    5. Tools - langchain.tools
    6. Embeddings - langchain.embeddings (or langchain_huggingface for local)

Requirements:
- Your implementation must import and use at least one component from each module
- The application should be runnable and demonstrate meaningful functionality
- You are free to build any application you like (chatbot, RAG system, agent, etc.)

Hints:
- Review the LangChain documentation for each module
- A simple approach is to create an agent with custom tools
- You can use API-based models (OpenAI, Anthropic) or local HuggingFace models
- For local models, no API keys are required!
"""

# ==============================================================================
# Agents module imports
# Example: from langchain.agents import create_agent
# ==============================================================================
# Fill in your imports


# ==============================================================================
# Middleware module imports
# Example: from langchain.agents.middleware import ModelRetryMiddleware
# ==============================================================================
# Fill in your imports


# ==============================================================================
# Models module imports
# Option 1 (API-based): from langchain.chat_models import init_chat_model
# Option 2 (Local HuggingFace):
#   from langchain_huggingface import ChatHuggingFace, HuggingFacePipeline
# ==============================================================================
# Fill in your imports


# ==============================================================================
# Messages module imports
# Example: from langchain.messages import HumanMessage, AIMessage, SystemMessage
# ==============================================================================
# Fill in your imports


# ==============================================================================
# Tools module imports
# Example: from langchain.tools import tool
# ==============================================================================
# Fill in your imports


# ==============================================================================
# Embeddings module imports
# Option 1 (API-based): from langchain.embeddings import init_embeddings
# Option 2 (Local HuggingFace):
#   from langchain_huggingface import HuggingFaceEmbeddings
# ==============================================================================
# Fill in your imports


####################
# Define your tools
####################

# Use the @tool decorator to create custom tools
# Example:
# @tool
# def my_tool(arg: str) -> str:
#     """Description of what this tool does."""
#     return f"Result: {arg}"

# Fill in your tool definitions


########################
# Define your embeddings
########################

# Initialize an embeddings model
# API-based example:
#   embeddings = init_embeddings("openai:text-embedding-3-small")
# Local HuggingFace example:
#   embeddings = HuggingFaceEmbeddings(
#       model_name="sentence-transformers/all-MiniLM-L6-v2",
#       model_kwargs={"device": "cpu"},
#   )

# Fill in your embeddings setup


#######################
# Define your model(s)
#######################

# Initialize your LLM/Chat model
# API-based example:
#   model = init_chat_model("openai:gpt-4o-mini", temperature=0)
# Local HuggingFace example:
#   from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
#   tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen2-1.5B-Instruct")
#   model = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2-1.5B-Instruct", device_map="cpu")
#   pipe = pipeline("text-generation", model=model, tokenizer=tokenizer, max_new_tokens=256)
#   llm = HuggingFacePipeline(pipeline=pipe)
#   chat_model = ChatHuggingFace(llm=llm)

# Fill in your model setup


########################
# Define your middleware
########################

# Set up any middleware for retry logic, rate limiting, etc.
# Example: middleware = [ModelRetryMiddleware(max_retries=3)]

# Fill in your middleware setup


#######################
# Define your messages
#######################

# Create message objects for your conversation
# Example:
# messages = [
#     SystemMessage(content="You are a helpful assistant."),
#     HumanMessage(content="Hello!"),
# ]

# Fill in your messages


#####################
# Define your agent
#####################

# Create an agent that uses your tools and model
# Example:
# agent = create_agent(
#     model=model,
#     tools=tools,
#     system_prompt="Your system prompt here",
#     middleware=middleware,
# )

# Fill in your agent setup


#################
# Main execution
#################

def main():
    """
    Main function to run your LangChain application.

    This function should demonstrate the use of all six modules working together.
    """
    # Fill in your main logic
    print("LangChain Example - Implement your solution!")
    print("Make sure to use all six modules:")
    print("  1. Agents (langchain.agents)")
    print("  2. Middleware (langchain.agents.middleware)")
    print("  3. Models (langchain.chat_models or langchain_huggingface)")
    print("  4. Messages (langchain.messages)")
    print("  5. Tools (langchain.tools)")
    print("  6. Embeddings (langchain.embeddings or langchain_huggingface)")


if __name__ == "__main__":
    main()
