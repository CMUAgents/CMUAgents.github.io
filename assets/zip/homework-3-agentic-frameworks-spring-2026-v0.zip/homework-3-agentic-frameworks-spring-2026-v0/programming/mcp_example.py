#!/usr/bin/env python3
"""
MCP Server Example - Exploring MCP Features

NOTE: This starter code was developed using Python 3.14 and MCP 1.0.0.
Depending on your Python version, you may need to adjust imports or install
different packages. Refer to the MCP documentation for your version.

In this exercise, you will create an MCP server that demonstrates
the use of at least the following features:
    1. Tools - Functions that the AI model can execute
    2. Resources - Context and data exposed to clients

You may optionally also include:
    3. Prompts - Templated messages and workflows

Requirements:
- Your implementation must include at least one Tool and one Resource
- The server should be runnable and demonstrate meaningful functionality
- You are free to build any type of server you like

Testing your server:
- You can use the MCP Inspector to test your server:
  https://modelcontextprotocol.io/docs/tools/inspector
- Run: npx @anthropic-ai/mcp-inspector python programming/mcp_example.py

Hints:
- Review the MCP documentation for each feature
- Use the @mcp.tool() decorator to define tools
- Use the @mcp.resource() decorator to define resources
- Use the @mcp.prompt() decorator to define prompts (optional)
"""

from mcp.server.fastmcp import FastMCP

# Initialize the MCP server with a name
mcp = FastMCP("my-mcp-server")


####################
# Define your tools
####################

# Use the @mcp.tool() decorator to create tools
# Example:
# @mcp.tool()
# def my_tool(arg: str) -> str:
#     """Description of what this tool does."""
#     return f"Result: {arg}"

# Fill in your tool definitions


########################
# Define your resources
########################

# Use the @mcp.resource() decorator to create resources
# Resources provide context and data to clients
# Example:
# @mcp.resource("config://settings")
# def get_settings() -> str:
#     """Return the current settings."""
#     return "Setting1: value1\nSetting2: value2"

# Fill in your resource definitions


#######################
# Define your prompts (optional)
#######################

# Use the @mcp.prompt() decorator to create prompts
# Prompts are templated messages for users
# Example:
# @mcp.prompt()
# def greeting_prompt(name: str) -> str:
#     """Generate a greeting prompt."""
#     return f"Please greet {name} warmly."

# Fill in your prompt definitions (optional)


#################
# Main execution
#################

if __name__ == "__main__":
    # Run the MCP server
    # This will start the server and listen for connections
    print("Starting MCP server...")
    print("Make sure to implement at least:")
    print("  1. One Tool (@mcp.tool)")
    print("  2. One Resource (@mcp.resource)")
    mcp.run()
