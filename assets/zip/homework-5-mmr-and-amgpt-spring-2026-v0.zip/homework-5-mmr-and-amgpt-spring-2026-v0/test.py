import sys
import unittest
import importlib

def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <module_name>")
        print("Example: test.py dpr")
        sys.exit(1)

    module_name = sys.argv[1]

    module = importlib.import_module(f"programming.{module_name}")
    # # Import the specified module from programming/
    # try:
    #     module = importlib.import_module(f"programming.{module_name}")
    # except ModuleNotFoundError:
    #     print(f"Module 'programming.{module_name}' not found")
    #     sys.exit(1)

    # Inject as programming.<module_name> so tests can import from it
    sys.modules[f"programming.{module_name}"] = module

    suite = unittest.defaultTestLoader.loadTestsFromName(f"tests.test_{module_name}")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)

if __name__ == "__main__":
    main()
