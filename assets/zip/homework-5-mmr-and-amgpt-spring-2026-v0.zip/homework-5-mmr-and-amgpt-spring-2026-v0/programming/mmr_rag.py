"""
MMR-RAG Implementation - Student Version

This module implements Maximal Marginal Relevance (MMR) for RAG systems based on:
"The Use of MMR, Diversity-Based Reranking for Reordering Documents and
Producing Summaries" (Carbonell & Goldstein, 1998)

And its application to RAG as discussed in:
"Diversity Matters: Enhancing Retrieval-Augmented Generation through
Diversified Content Selection" (Wang et al., 2025)

MMR balances relevance to the query with diversity among selected documents:

MMR(D_i) = lambda * sim(D_i, Q) - (1 - lambda) * max(sim(D_i, D_j))

where:
- D_i is a candidate document
- Q is the query
- D_j are already selected documents
- lambda controls the relevance-diversity tradeoff
"""

import random
import numpy as np
from typing import List, Dict, Tuple, Optional

# Set seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

# Default lambda value (as suggested in Carbonell & Goldstein, 1998)
DEFAULT_LAMBDA = 0.5


def compute_cosine_similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
    """
    Compute the cosine similarity between two vectors.

    Cosine similarity measures the cosine of the angle between two vectors,
    ranging from -1 (opposite) to 1 (identical direction).

    Formula: cos(theta) = (A . B) / (||A|| * ||B||)

    Args:
        vec1: First vector as numpy array of shape (dim,)
        vec2: Second vector as numpy array of shape (dim,)

    Returns:
        The cosine similarity as a float between -1 and 1

    Example:
        >>> v1 = np.array([1.0, 0.0])
        >>> v2 = np.array([1.0, 0.0])
        >>> compute_cosine_similarity(v1, v2)
        1.0
        >>> v3 = np.array([0.0, 1.0])
        >>> compute_cosine_similarity(v1, v3)
        0.0

    Hints:
        - Use np.dot() for the dot product
        - Use np.linalg.norm() for vector magnitude
        - Handle the case where either vector has zero magnitude
    """
    # TODO: Implement cosine similarity
    # Step 1: Compute the dot product of vec1 and vec2
    # Step 2: Compute the L2 norm (magnitude) of each vector
    # Step 3: Handle edge case where either norm is zero (return 0.0)
    # Step 4: Return dot_product / (norm1 * norm2)
    pass


def compute_mmr_score(
    candidate_embedding: np.ndarray,
    query_embedding: np.ndarray,
    selected_embeddings: List[np.ndarray],
    lambda_param: float = DEFAULT_LAMBDA
) -> float:
    """
    Compute the MMR score for a candidate document.

    MMR(D_i) = lambda * sim(D_i, Q) - (1 - lambda) * max_{D_j in S}(sim(D_i, D_j))

    When no documents have been selected yet, the diversity penalty is 0.

    Args:
        candidate_embedding: Embedding vector for the candidate document
        query_embedding: Embedding vector for the query
        selected_embeddings: List of embedding vectors for already selected documents
        lambda_param: Tradeoff parameter (0 = max diversity, 1 = max relevance)

    Returns:
        The MMR score for the candidate document

    Example:
        >>> query = np.array([1.0, 0.0, 0.0])
        >>> candidate = np.array([0.9, 0.1, 0.0])
        >>> selected = [np.array([0.8, 0.2, 0.0])]
        >>> score = compute_mmr_score(candidate, query, selected, lambda_param=0.5)

    Hints:
        - Use compute_cosine_similarity() to compute similarities
        - If selected_embeddings is empty, max_sim_to_selected should be 0.0
        - Apply the MMR formula: lambda * relevance - (1-lambda) * max_similarity
    """
    # TODO: Implement MMR score computation
    # Step 1: Compute cosine similarity between candidate and query (relevance)
    # Step 2: If there are selected documents, compute max similarity to them
    #         Otherwise, set max_sim_to_selected = 0.0
    # Step 3: Apply MMR formula and return the score
    pass


def select_documents_mmr(
    query_embedding: np.ndarray,
    document_embeddings: np.ndarray,
    k: int,
    lambda_param: float = DEFAULT_LAMBDA
) -> List[int]:
    """
    Select k documents using the MMR algorithm.

    Iteratively selects documents that maximize the MMR criterion,
    balancing relevance to the query with diversity from already
    selected documents.

    Args:
        query_embedding: Embedding vector for the query, shape (dim,)
        document_embeddings: Matrix of document embeddings, shape (n_docs, dim)
        k: Number of documents to select
        lambda_param: Tradeoff parameter (0 = max diversity, 1 = max relevance)

    Returns:
        List of indices of selected documents in order of selection

    Example:
        >>> query = np.array([1.0, 0.0])
        >>> docs = np.array([[0.9, 0.1], [0.8, 0.2], [0.1, 0.9]])
        >>> indices = select_documents_mmr(query, docs, k=2, lambda_param=0.5)
        >>> len(indices)
        2

    Hints:
        - Keep track of selected indices and their embeddings
        - Use a set to track remaining (unselected) indices for efficiency
        - In each iteration, find the document with the highest MMR score
        - Use compute_mmr_score() to evaluate each candidate
    """
    # TODO: Implement MMR document selection
    # Step 1: Initialize selected_indices list, selected_embeddings list,
    #         and remaining_indices set
    # Step 2: Ensure k doesn't exceed the number of documents
    # Step 3: Loop k times:
    #         - For each remaining document, compute its MMR score
    #         - Select the document with the highest score
    #         - Add it to selected lists and remove from remaining
    # Step 4: Return the list of selected indices
    pass


def mmr_rerank(
    query_embedding: np.ndarray,
    document_embeddings: np.ndarray,
    initial_scores: np.ndarray,
    k: int,
    lambda_param: float = DEFAULT_LAMBDA
) -> List[Tuple[int, float]]:
    """
    Rerank documents using MMR, incorporating initial retrieval scores.

    This function combines initial retrieval scores with MMR to rerank
    a set of candidate documents. Useful when you have pre-filtered
    candidates from a first-stage retriever.

    The modified MMR formula uses the initial score as the relevance term:
    MMR(D_i) = lambda * score(D_i) - (1 - lambda) * max(sim(D_i, D_j))

    Args:
        query_embedding: Embedding vector for the query
        document_embeddings: Matrix of document embeddings, shape (n_docs, dim)
        initial_scores: Array of initial retrieval scores, shape (n_docs,)
        k: Number of documents to return
        lambda_param: Tradeoff parameter

    Returns:
        List of (index, mmr_score) tuples for the top-k documents

    Example:
        >>> query = np.array([1.0, 0.0])
        >>> docs = np.array([[0.9, 0.1], [0.8, 0.2], [0.1, 0.9]])
        >>> scores = np.array([0.95, 0.85, 0.3])
        >>> results = mmr_rerank(query, docs, scores, k=2)

    Hints:
        - Normalize initial_scores to [0, 1] range first
        - Use a similar iterative approach as select_documents_mmr
        - The relevance term uses normalized_scores[idx] instead of
          cosine similarity to query
    """
    # TODO: Implement MMR reranking with initial scores
    # Step 1: Normalize initial_scores to [0, 1] range
    #         Handle case where all scores are equal
    # Step 2: Initialize tracking variables (similar to select_documents_mmr)
    # Step 3: Loop k times, computing modified MMR score for each candidate:
    #         mmr_score = lambda * normalized_score - (1-lambda) * max_sim
    # Step 4: Return list of (index, score) tuples
    pass


if __name__ == "__main__":
    print("=== MMR-RAG Demo ===\n")

    # Create sample embeddings
    np.random.seed(SEED)

    # Query about machine learning
    query_embedding = np.array([0.8, 0.6, 0.0, 0.0])
    query_embedding = query_embedding / np.linalg.norm(query_embedding)

    # Document embeddings (simulating different topics)
    # Doc 0: Very similar to query (ML focused)
    # Doc 1: Similar to query and Doc 0 (also ML focused)
    # Doc 2: Different topic (NLP focused)
    # Doc 3: Different topic (CV focused)
    # Doc 4: Similar to Doc 0 (redundant ML)
    document_embeddings = np.array([
        [0.85, 0.52, 0.05, 0.05],  # ML doc 1
        [0.82, 0.55, 0.08, 0.08],  # ML doc 2 (similar to doc 1)
        [0.3, 0.2, 0.9, 0.1],      # NLP doc
        [0.2, 0.3, 0.1, 0.9],      # CV doc
        [0.83, 0.54, 0.06, 0.06],  # ML doc 3 (similar to doc 1)
    ])
    # Normalize
    document_embeddings = document_embeddings / np.linalg.norm(
        document_embeddings, axis=1, keepdims=True
    )

    document_names = [
        "Machine Learning Basics",
        "Introduction to ML Algorithms",
        "Natural Language Processing",
        "Computer Vision Fundamentals",
        "ML Model Training"
    ]

    print("Query embedding:", query_embedding)
    print("\nDocument embeddings shape:", document_embeddings.shape)
    print()

    # Test different lambda values
    for lambda_val in [1.0, 0.5, 0.0]:
        print(f"\n--- Lambda = {lambda_val} ---")
        selected = select_documents_mmr(
            query_embedding,
            document_embeddings,
            k=3,
            lambda_param=lambda_val
        )
        if selected is not None:
            print(f"Selected documents (in order): {selected}")
            for i, idx in enumerate(selected, 1):
                sim = compute_cosine_similarity(query_embedding, document_embeddings[idx])
                if sim is not None:
                    print(f"  {i}. [{idx}] {document_names[idx]} (sim to query: {sim:.4f})")
        else:
            print("  Not implemented yet")

    print("\n\n=== MMR Reranking Demo ===\n")

    # Initial retrieval scores (e.g., from BM25 or dense retrieval)
    initial_scores = np.array([0.95, 0.92, 0.4, 0.35, 0.90])

    print("Initial scores:", initial_scores)
    print("Pure relevance ranking:", np.argsort(initial_scores)[::-1][:3].tolist())

    reranked = mmr_rerank(
        query_embedding,
        document_embeddings,
        initial_scores,
        k=3,
        lambda_param=0.5
    )
    if reranked is not None:
        print(f"\nMMR reranked (lambda=0.5): {[idx for idx, _ in reranked]}")
        for idx, score in reranked:
            print(f"  [{idx}] {document_names[idx]} (MMR score: {score:.4f})")
    else:
        print("\nNot implemented yet")
