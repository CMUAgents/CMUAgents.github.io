import random
import unittest
import numpy as np

from gradescope_utils.autograder_utils.decorators import weight, number

# Set seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

try:
    from programming.mmr_rag import (
        compute_cosine_similarity,
        compute_mmr_score,
        select_documents_mmr,
        mmr_rerank,
    )
except ImportError:
    from mmr_rag import (
        compute_cosine_similarity,
        compute_mmr_score,
        select_documents_mmr,
        mmr_rerank,
    )


class TestComputeCosineSimilarity(unittest.TestCase):
    """Tests for compute_cosine_similarity function."""

    @weight(2)
    @number("2.1")
    def test_cosine_similarity_identical_vectors(self):
        """Test cosine similarity returns 1.0 for identical vectors."""
        vec1 = np.array([1.0, 2.0, 3.0])
        vec2 = np.array([1.0, 2.0, 3.0])
        result = compute_cosine_similarity(vec1, vec2)
        self.assertAlmostEqual(result, 1.0, places=5)

    @weight(2)
    @number("2.2")
    def test_cosine_similarity_orthogonal_vectors(self):
        """Test cosine similarity returns 0.0 for orthogonal vectors."""
        vec1 = np.array([1.0, 0.0, 0.0])
        vec2 = np.array([0.0, 1.0, 0.0])
        result = compute_cosine_similarity(vec1, vec2)
        self.assertAlmostEqual(result, 0.0, places=5)


class TestComputeMMRScore(unittest.TestCase):
    """Tests for compute_mmr_score function."""

    @weight(2)
    @number("2.3")
    def test_mmr_score_no_selected_documents(self):
        """Test MMR score when no documents have been selected yet."""
        # When no documents are selected, MMR = lambda * relevance
        query = np.array([1.0, 0.0, 0.0])
        candidate = np.array([0.8, 0.6, 0.0])
        candidate = candidate / np.linalg.norm(candidate)  # Normalize
        selected = []
        lambda_param = 0.5

        result = compute_mmr_score(candidate, query, selected, lambda_param)

        # Expected: lambda * cos_sim(candidate, query) - 0
        expected_relevance = compute_cosine_similarity(candidate, query)
        expected = lambda_param * expected_relevance
        self.assertAlmostEqual(result, expected, places=5)

    @weight(2)
    @number("2.4")
    def test_mmr_score_with_selected_documents(self):
        """Test MMR score with previously selected documents."""
        query = np.array([1.0, 0.0, 0.0])
        candidate = np.array([0.8, 0.6, 0.0])
        candidate = candidate / np.linalg.norm(candidate)

        # Selected document that is similar to candidate
        selected_doc = np.array([0.7, 0.7, 0.1])
        selected_doc = selected_doc / np.linalg.norm(selected_doc)
        selected = [selected_doc]

        lambda_param = 0.5

        result = compute_mmr_score(candidate, query, selected, lambda_param)

        # Manual calculation
        relevance = compute_cosine_similarity(candidate, query)
        max_sim = compute_cosine_similarity(candidate, selected_doc)
        expected = lambda_param * relevance - (1 - lambda_param) * max_sim

        self.assertAlmostEqual(result, expected, places=5)


class TestSelectDocumentsMMR(unittest.TestCase):
    """Tests for select_documents_mmr function."""

    @weight(2)
    @number("2.5")
    def test_select_documents_mmr_diversity(self):
        """Test that MMR with low lambda selects diverse documents."""
        # Query about machine learning
        query = np.array([1.0, 0.0])
        query = query / np.linalg.norm(query)

        # Three documents:
        # Doc 0: Very relevant to query (ML)
        # Doc 1: Also relevant to query, similar to Doc 0 (redundant ML)
        # Doc 2: Less relevant but different topic (NLP)
        docs = np.array([
            [0.95, 0.05],  # Very similar to query
            [0.90, 0.10],  # Also similar to query AND similar to doc 0
            [0.30, 0.95],  # Different direction (diverse)
        ])
        docs = docs / np.linalg.norm(docs, axis=1, keepdims=True)

        # With lambda=1.0 (pure relevance), should get [0, 1] as top 2
        pure_relevance = select_documents_mmr(query, docs, k=2, lambda_param=1.0)
        self.assertEqual(pure_relevance[0], 0)  # Most relevant first
        self.assertEqual(pure_relevance[1], 1)  # Second most relevant

        # With lambda=0.3 (more diversity), the second pick should be doc 2
        # because doc 1 is too similar to doc 0
        with_diversity = select_documents_mmr(query, docs, k=2, lambda_param=0.3)
        self.assertEqual(with_diversity[0], 0)  # Still pick most relevant first
        self.assertEqual(with_diversity[1], 2)  # But then pick diverse doc


if __name__ == "__main__":
    unittest.main()
