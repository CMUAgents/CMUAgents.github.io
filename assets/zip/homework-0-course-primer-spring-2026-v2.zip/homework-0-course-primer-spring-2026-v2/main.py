def main():
    print("Hello from homework-0-course-primer!")


if __name__ == "__main__":
    main()
