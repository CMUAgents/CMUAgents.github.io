# homework-0-course-primer
First homework of the course consisting of sample problems and starter tasks.
