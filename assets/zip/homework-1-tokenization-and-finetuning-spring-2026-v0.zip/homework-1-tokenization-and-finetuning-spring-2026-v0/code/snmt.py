"""
Subword NMT Homework: BPE Parameter Tuning

Fill in the parameter values below to pass the tests.
Run this file to see your results: uv run code/snmt.py
"""

from snmt_utils import snmt_learn_bpe, snmt_get_vocab, snmt_apply_bpe

# Fill In
TRAIN_TEXT = """ 
"""

INPUT_TEXT = "" # Fill In 

NUM_OPERATIONS = 1  # Adjust number of operations


if __name__ == "__main__":
    # Step 1: Learn BPE codes from training text
    print("=== Step 1: snmt_learn_bpe ===")
    codes, segmented = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
    print(f"Segmented: {segmented}")
    print(f"Tokens: {len(segmented.split())}")

    # Step 2: Get vocabulary from segmented text
    print("\n=== Step 2: snmt_get_vocab ===")
    vocab = snmt_get_vocab(segmented)
    print(f"Vocabulary: {vocab}")
    print(f"Vocab size: {len(vocab)}")

    # Step 3: Apply BPE to input text
    print("\n=== Step 3: snmt_apply_bpe ===")
    applied = snmt_apply_bpe(INPUT_TEXT, codes)
    tokens = applied.split()
    complete_tokens = sum(1 for t in tokens if not t.endswith("@@"))
    partial_tokens = sum(1 for t in tokens if t.endswith("@@"))
    print(f"Input: {INPUT_TEXT}")
    print(f"Segmented: {applied}")
    print(f"Tokens: {len(tokens)}")
    print(f"Complete tokens: {complete_tokens}")
    print(f"Partial tokens: {partial_tokens}")
