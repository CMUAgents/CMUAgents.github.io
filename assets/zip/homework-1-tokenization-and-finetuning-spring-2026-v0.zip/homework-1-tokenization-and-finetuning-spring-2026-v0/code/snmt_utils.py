from subword_nmt.learn_bpe import learn_bpe
from subword_nmt.apply_bpe import BPE
from subword_nmt.get_vocab import get_vocab
from subword_nmt.segment_char_ngrams import segment_char_ngrams
import io

def snmt_learn_bpe(text, num_operations=10):
    """
    Learn BPE operations from input text and return codes and segmented text.

    Args:
        text: Input text to segment
        num_operations: Number of BPE merge operations to learn

    Returns:
        Tuple of (bpe_codes, segmented_text):
            - bpe_codes: String containing learned BPE merge operations
            - segmented_text: Text segmented with BPE tokens separated by '@@'
    """
    # Learn BPE operations from the input text
    input_file = io.StringIO(text)
    output_file = io.StringIO()

    learn_bpe(input_file, output_file, num_symbols=num_operations)

    # Get the learned codes
    output_file.seek(0)
    codes = output_file.read()

    # Apply learned BPE operations
    output_file.seek(0)
    bpe = BPE(output_file)

    # Segment the text
    segmented = bpe.process_line(text)

    return codes, segmented


def snmt_apply_bpe(text, bpe_codes, vocab=None, vocab_threshold=None):
    """
    Apply pre-learned BPE codes to segment text.

    Args:
        text: Input text to segment
        bpe_codes: String containing BPE merge operations (one per line)
        vocab: Optional dict from snmt_get_vocab. If provided, reverts merges
               that produce out-of-vocabulary tokens.
        vocab_threshold: Optional frequency threshold. Tokens with frequency
                        below this are treated as OOV.

    Returns:
        Segmented text with BPE tokens separated by '@@'
    """
    codes_file = io.StringIO(bpe_codes)

    # Convert vocab dict to set, filtering by threshold if provided
    vocab_set = None
    if vocab is not None:
        if vocab_threshold is not None:
            vocab_set = {word for word, freq in vocab.items() if freq >= vocab_threshold}
        else:
            vocab_set = set(vocab.keys())

    bpe = BPE(codes_file, vocab=vocab_set)
    segmented = bpe.process_line(text)
    return segmented


def snmt_get_vocab(text):
    """
    Extract vocabulary with frequency counts from text.

    Args:
        text: Input text to extract vocabulary from

    Returns:
        Dictionary mapping tokens to their frequency counts
    """
    input_file = io.StringIO(text)
    output_file = io.StringIO()

    get_vocab(input_file, output_file)

    output_file.seek(0)
    vocab = {}
    for line in output_file:
        parts = line.strip().split()
        if len(parts) == 2:
            token, count = parts
            vocab[token] = int(count)
    return vocab


def snmt_segment_char_ngrams(text, n=3, vocab=None):
    """
    Segment text into character n-grams.

    Args:
        text: Input text to segment
        n: Size of character n-grams
        vocab: Optional vocabulary file-like object for shortlisting

    Returns:
        Segmented text with character n-grams
    """
    import argparse

    input_file = io.StringIO(text)
    output_file = io.StringIO()
    vocab_file = vocab if vocab else io.StringIO("")

    args = argparse.Namespace(
        input=input_file,
        output=output_file,
        n=n,
        shortlist=0,
        vocab=vocab_file,
        separator="@@"
    )

    segment_char_ngrams(args)

    output_file.seek(0)
    return output_file.read().strip()
