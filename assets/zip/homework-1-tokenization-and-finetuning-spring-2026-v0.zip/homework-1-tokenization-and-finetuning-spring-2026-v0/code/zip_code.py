import os
import zipfile
import glob

zip_name = "code.zip"
code_dir = os.path.dirname(os.path.abspath(__file__))

# Include all problem_*.py files
include_patterns = ["*.py"]

with zipfile.ZipFile(os.path.join(code_dir, zip_name), "w", zipfile.ZIP_DEFLATED) as z:
    for pattern in include_patterns:
        for file_path in glob.glob(os.path.join(code_dir, pattern)):
            arcname = os.path.basename(file_path)
            z.write(file_path, arcname)

print(f"Created {zip_name}")
