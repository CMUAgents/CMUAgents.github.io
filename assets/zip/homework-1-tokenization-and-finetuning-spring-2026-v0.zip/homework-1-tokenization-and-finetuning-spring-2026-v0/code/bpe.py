from string import ascii_letters, digits, punctuation
from typing import cast, TypedDict

characters = list(ascii_letters + digits + punctuation)

class BytePairTable(TypedDict):
    character: list[str]
    leftcode: list[str]
    rightcode: list[str | int]

def bpe_compression(input_string: str) -> tuple[BytePairTable, str]:
    byte_pair_table = BytePairTable(
        character = characters.copy(),
        leftcode = characters.copy(),
        rightcode = []
    )

    # Initial rightcode set
    for character in byte_pair_table["character"]:
        if character in input_string:
            byte_pair_table["rightcode"].append() # Fill in 
        else:
            byte_pair_table["rightcode"].append() # Fill in 

    buffer = input_string
    most_frequent_pair_value = None

    while most_frequent_pair_value is None or most_frequent_pair_value > 1:
        pair_map: dict[str, int] = {}
        buffer_length = len(buffer)

        for character_index in range(1, buffer_length):
            pair: str = # Fill in

            # Initialize / Increment counter on pair_map

        most_frequent_pair_value: int = # Fill in

        if most_frequent_pair_value > 1:
            most_frequent_pair_key: str = # Fill in 

            # Find new character assignment.
            first_unused_character_index = next((i for i, v in enumerate(byte_pair_table["rightcode"]) if v == 0), None)
            if first_unused_character_index is None:
                # No more unused characters
                return (byte_pair_table, buffer)

            # Update table with character
            byte_pair_table["leftcode"][first_unused_character_index] = # Fill in 
            byte_pair_table["rightcode"][first_unused_character_index] = # Fill in 
            replacement_character = # Fill in 

            buffer = buffer.replace(most_frequent_pair_key, replacement_character)

    return (byte_pair_table, buffer)

def bpe_expansion(byte_pair_table: BytePairTable, buffer: str) -> str:

    input = list(buffer)
    input.reverse()

    stack: list[str] = []
    output_string = ""

    while len(input) > 0 or len(stack) > 0:
        if len(stack) > 0:
            character = stack.pop()
            character_index = # Fill in 
            leftcode_value = # Fill in
            rightcode_value = # Fill in

            if rightcode_value == 1:
                # This means that its a literal
                output_string += # Fill in

            elif isinstance(rightcode_value, str):
                # If the rightcode_value is string, then its a pair
                stack.append(# Fill in)
                stack.append(# Fill in)

        else:
            character = input.pop()
            stack.append(character)

    return output_string

if __name__ == "__main__":
    input_string = "ababcabcd"
    print(f"input_string: {input_string}")

    byte_pair_table, buffer = bpe_compression(input_string)
    print(f"buffer: {buffer}")

    output_string = bpe_expansion(byte_pair_table, buffer)
    print(f"output_string: {output_string}")
