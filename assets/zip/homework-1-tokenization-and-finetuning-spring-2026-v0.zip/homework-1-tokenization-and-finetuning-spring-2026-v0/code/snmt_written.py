import re

from snmt_utils import snmt_learn_bpe, snmt_get_vocab, snmt_apply_bpe, snmt_segment_char_ngrams

if __name__ == "__main__":
    # BPE codes will be obtained from this string
    train_text = """The quick brown fox jumped over the lazy dog.
    I ordered a hamburger from mcdonalds.
    I ordered a cheeseburger from mcdonalds.
    I ordered a double bacon cheeseburger from burger king.
    I ordered a double-double from in-in-out burger.
    How much wood could a woodchuck chuck if a woodchuck could chuck wood.
    Buffalo buffalo Buffalo buffalo buffalo buffalo Buffalo buffalo.
    """

    input_text = "I ordered a burger and buffalo wings for Chuck" 

    num_operations = 20
    vocab_threshold = 2

    # Step 1: Learn BPE codes from training text
    print("=== Step 1: snmt_learn_bpe ===")
    codes, segmented = snmt_learn_bpe(train_text, num_operations=num_operations)
    print(f"Segmented: {segmented}")
    print(f"Learned codes:\n{codes}")
    print(f"Tokens: {len(segmented.split())}")

    # Step 2: Get vocabulary from segmented text
    print("=== Step 2: snmt_get_vocab ===")
    vocab = snmt_get_vocab(segmented)
    print(f"Vocabulary: {vocab}")
    print(f"Vocab size: {len(vocab)}")

    # Step 3: Apply BPE to new text (without vocab constraint)
    print("\n=== Step 3a: snmt_apply_bpe (no vocab) ===")
    result = snmt_apply_bpe(input_text, codes)
    print(f"Input: {input_text}")
    print(f"Segmented: {result}")
    print(f"Tokens: {len(result.split())}")

    # Step 3b: Apply BPE with vocab constraint (reverts OOV merges)
    print(f"\n=== Step 3b: snmt_apply_bpe (with vocab, threshold={vocab_threshold}) ===")
    result_with_vocab = snmt_apply_bpe(input_text, codes, vocab=vocab, vocab_threshold=vocab_threshold)
    print(f"Input: {input_text}")
    print(f"Segmented: {result_with_vocab}")
    print(f"Tokens: {len(result_with_vocab.split())}")

    # Test segment_char_ngrams
    print("\n=== snmt_segment_char_ngrams ===")
    result = snmt_segment_char_ngrams(train_text, n=3)
    print(f"Segmented (n=3): {result}")
    print(f"Tokens: {len(result.split())}")

    # The original segmentation can be restored with a simple replacement:
    # sed -r 's/(@@ )|(@@ ?$)//g'
    print("\n=== Restore original from BPE ===")
    restored = re.sub(r"(@@ )|(@@ ?$)", "", segmented)
    print(f"Segmented: {segmented}")
    print(f"Restored:  {restored}")
