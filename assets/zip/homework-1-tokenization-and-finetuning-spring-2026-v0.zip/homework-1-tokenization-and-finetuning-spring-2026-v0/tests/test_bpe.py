import unittest

from gradescope_utils.autograder_utils.decorators import weight, number

try:
    from code.bpe import bpe_compression, bpe_expansion
except ImportError:
    from bpe import bpe_compression, bpe_expansion

class TestBPE(unittest.TestCase):
    @weight(1)
    @number("1.1")
    def test_basic_round_trip(self):
        """Test that compression followed by expansion returns the original string."""
        input_string = "ababcabcd"
        byte_pair_table, compressed = bpe_compression(input_string)
        output = bpe_expansion(byte_pair_table, compressed)
        self.assertEqual(output, input_string)

    @weight(1)
    @number("1.2")
    def test_simple_repeated_pair(self):
        """Test compression with a simple repeated pair."""
        input_string = "aaaaaa"
        byte_pair_table, compressed = bpe_compression(input_string)

        # Should compress the repeated 'aa' pairs
        self.assertLess(len(compressed), len(input_string))

        # Verify round trip
        output = bpe_expansion(byte_pair_table, compressed)
        self.assertEqual(output, input_string)

    @weight(1)
    @number("1.3")
    def test_no_repeated_pairs(self):
        """Test string with no repeated pairs."""
        input_string = "abcdef"
        byte_pair_table, compressed = bpe_compression(input_string)

        # No compression should occur
        self.assertEqual(compressed, input_string)

        # Verify round trip
        output = bpe_expansion(byte_pair_table, compressed)
        self.assertEqual(output, input_string)

    @weight(1)
    @number("1.4")
    def test_two_characters(self):
        """Test with two characters."""
        input_string = "ab"
        byte_pair_table, compressed = bpe_compression(input_string)

        # Pair appears only once, no compression
        self.assertEqual(compressed, input_string)

        # Verify round trip
        output = bpe_expansion(byte_pair_table, compressed)
        self.assertEqual(output, input_string)

    @weight(1)
    @number("1.5")
    def test_multiple_compression_iterations(self):
        """Test that multiple iterations of compression work correctly."""
        input_string = "abababab"
        byte_pair_table, compressed = bpe_compression(input_string)

        # Multiple 'ab' pairs should be compressed
        self.assertLess(len(compressed), len(input_string))

        # Verify round trip
        output = bpe_expansion(byte_pair_table, compressed)
        self.assertEqual(output, input_string)

    @weight(1)
    @number("1.6")
    def test_nested_pairs(self):
        """Test compression with nested pair patterns."""
        input_string = "aabbccaabbcc"
        byte_pair_table, compressed = bpe_compression(input_string)

        # Should compress repeated patterns
        self.assertLess(len(compressed), len(input_string))

        # Verify round trip
        output = bpe_expansion(byte_pair_table, compressed)
        self.assertEqual(output, input_string)

    @weight(1)
    @number("1.7")
    def test_mixed_characters(self):
        """Test with mixed alphanumeric and punctuation."""
        input_string = "Hello!!World!!123123"
        byte_pair_table, compressed = bpe_compression(input_string)

        # Verify round trip
        output = bpe_expansion(byte_pair_table, compressed)
        self.assertEqual(output, input_string)

    @weight(1)
    @number("1.8")
    def test_byte_pair_table_structure(self):
        """Test that the byte pair table has the correct structure."""
        input_string = "aabbcc"
        byte_pair_table, compressed = bpe_compression(input_string)

        # Check that all required keys exist
        self.assertIn("character", byte_pair_table)
        self.assertIn("leftcode", byte_pair_table)
        self.assertIn("rightcode", byte_pair_table)

        # Check that all lists have the same length
        self.assertEqual(len(byte_pair_table["character"]), len(byte_pair_table["leftcode"]))
        self.assertEqual(len(byte_pair_table["character"]), len(byte_pair_table["rightcode"]))

    @weight(1)
    @number("1.9")
    def test_rightcode_values(self):
        """Test that rightcode values are properly set."""
        input_string = "aabb"
        byte_pair_table, compressed = bpe_compression(input_string)

        # Characters used in the input should have rightcode != 0
        char_index_a = byte_pair_table["character"].index("a")
        char_index_b = byte_pair_table["character"].index("b")

        self.assertNotEqual(byte_pair_table["rightcode"][char_index_a], 0)
        self.assertNotEqual(byte_pair_table["rightcode"][char_index_b], 0)

    @weight(1)
    @number("1.10")
    def test_long_repeated_pattern(self):
        """Test with a longer repeated pattern."""
        input_string = "abcabc" * 10
        byte_pair_table, compressed = bpe_compression(input_string)

        # Should achieve significant compression
        self.assertLess(len(compressed), len(input_string))

        # Verify round trip
        output = bpe_expansion(byte_pair_table, compressed)
        self.assertEqual(output, input_string)
