import unittest

from gradescope_utils.autograder_utils.decorators import weight, number
try:
    from code.snmt import (
        TRAIN_TEXT,
        INPUT_TEXT,
        NUM_OPERATIONS,
    )
    from code.snmt_utils import snmt_learn_bpe, snmt_get_vocab, snmt_apply_bpe
except ImportError:
    from snmt import (
        TRAIN_TEXT,
        INPUT_TEXT,
        NUM_OPERATIONS,
    )
    from snmt_utils import snmt_learn_bpe, snmt_get_vocab, snmt_apply_bpe

class TestSNMT(unittest.TestCase):
    @weight(1)
    @number("2.1")
    def test_num_operations_limit(self):
        """NUM_OPERATIONS should be at most 20."""
        self.assertLessEqual(NUM_OPERATIONS, 20, f"NUM_OPERATIONS {NUM_OPERATIONS} exceeds 20")

    @weight(1)
    @number("2.2")
    def test_vocab_size_max(self):
        """Vocabulary Size: vocab size should be at most 100."""
        codes, segmented = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
        vocab = snmt_get_vocab(segmented)
        vocab_size = len(vocab)
        self.assertLessEqual(vocab_size, 100, f"Vocab size {vocab_size} exceeds 100")

    @weight(1)
    @number("2.3")
    def test_complete_token_the(self):
        """Complete Token: 'the' should appear as a complete token."""
        codes, segmented = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
        tokens = segmented.split()
        self.assertIn("the", tokens, "'the' not found as a complete token")

    @weight(1)
    @number("2.4")
    def test_complete_token_and(self):
        """Complete Token: 'and' should appear as a complete token."""
        codes, segmented = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
        tokens = segmented.split()
        self.assertIn("and", tokens, "'and' not found as a complete token")

    @weight(1)
    @number("2.5")
    def test_complete_token_a(self):
        """Complete Token: 'a' should appear as a complete token."""
        codes, segmented = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
        tokens = segmented.split()
        self.assertIn("a", tokens, "'a' not found as a complete token")

    @weight(1)
    @number("2.6")
    def test_input_text_segmentation(self):
        """INPUT_TEXT segmentation should produce less than 50 tokens."""
        codes, _ = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
        applied = snmt_apply_bpe(INPUT_TEXT, codes)
        token_count = len(applied.split())
        self.assertLess(token_count, 50, f"INPUT_TEXT token count {token_count} is not less than 50")

    @weight(1)
    @number("2.7")
    def test_subword_er(self):
        """Subword: 'er' should appear in vocabulary."""
        codes, segmented = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
        vocab = snmt_get_vocab(segmented)
        has_er = "er" in vocab or "er@@" in vocab
        self.assertTrue(has_er, "'er' not found in vocabulary")

    @weight(1)
    @number("2.8")
    def test_input_text_complete_and_partial_tokens(self):
        """INPUT_TEXT should have at least 5 complete tokens and 5 partial tokens."""
        codes, _ = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
        applied = snmt_apply_bpe(INPUT_TEXT, codes)
        tokens = applied.split()
        complete_tokens = sum(1 for t in tokens if not t.endswith("@@"))
        partial_tokens = sum(1 for t in tokens if t.endswith("@@"))
        self.assertGreaterEqual(complete_tokens, 5, f"INPUT_TEXT has only {complete_tokens} complete tokens (need 5)")
        self.assertGreaterEqual(partial_tokens, 5, f"INPUT_TEXT has only {partial_tokens} partial tokens (need 5)")

    @weight(1)
    @number("2.9")
    def test_subword_th(self):
        """Subword: 'th' should appear in vocabulary."""
        codes, segmented = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
        vocab = snmt_get_vocab(segmented)
        has_th = "th" in vocab or "th@@" in vocab
        self.assertTrue(has_th, "'th' not found in vocabulary")

    @weight(1)
    @number("2.10")
    def test_subword_an(self):
        """Subword: 'an' should appear in vocabulary."""
        codes, segmented = snmt_learn_bpe(TRAIN_TEXT, num_operations=NUM_OPERATIONS)
        vocab = snmt_get_vocab(segmented)
        has_an = "an" in vocab or "an@@" in vocab
        self.assertTrue(has_an, "'an' not found in vocabulary")
