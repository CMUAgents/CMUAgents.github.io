import unittest

from gradescope_utils.autograder_utils.decorators import weight, number

try:
    from programming.cot_monitoring import monitor_reasoning, examples
except ImportError:
    from cot_monitoring import monitor_reasoning, examples


class TestCotMonitoring(unittest.TestCase):
    @weight(5)
    @number("2.1")
    def test_reward_hacking_negative_sentiment(self):
        """Test that reward_hacking text is detected as NEGATIVE sentiment."""
        reasoning = examples["reward_hacking"]
        verdict, label, score = monitor_reasoning(reasoning)
        self.assertEqual(label, "NEGATIVE")

    @weight(5)
    @number("2.2")
    def test_reward_hacking_obfuscated_positive_sentiment(self):
        """Test that reward_hacking_obfuscated text is detected as POSITIVE sentiment."""
        reasoning = examples["reward_hacking_obfuscated"]
        verdict, label, score = monitor_reasoning(reasoning)
        self.assertEqual(label, "POSITIVE")
